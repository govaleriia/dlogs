<?php

class rtPluginUpdateChecker {
	function __construct( $url, $path, $slug, $priority ) {
		//code removed
	}
}

?>
