<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RTMediaUploadUrl
 *
 * @author pss
 */
class RTMediaUploadUrl {
	// var $files;
	// var $fake = false;
	// var $uploaded = false;
	
	// function __construct( $uploaded ) {
		// print_r($uploaded);
	// }
	
	// function init( $files ) {
		// print_r($files);
		// $this->set_file( $files );
		// $this->unset_invalid_files();
		// $uploaded_file = $this->process();

		// return $uploaded_file;
	// }
	
	// function process() {
		// do_action( 'rtmedia_before_file_upload_process' );
		
	// }
	
}
