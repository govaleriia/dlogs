# Added: grunt environment

# Removed: Foundation framework

# Removed: Unused image files.

# Removed: Unused CSS and JS files.

# Changed: CSS file structure