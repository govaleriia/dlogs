jQuery( document ).ready( function(){

	var rtm_fb_uid = '';
	var rtm_fb_accesstoken = '';
	var rtm_si_upload_total = 0;
	var rtm_si_api_offset = 0;
	var rtm_si_api_limit = 100;
	var rtm_si_magnificpopup;
	var rtm_ss_media_upload = false;
	var rtm_ss_album_cover_count = 4;
	var rtm_ss_is_album = true;
	var rtm_ss_activity_id = false;
	var rtm_ss_media_array;
	var rtm_ss_album_array;
	var rtm_ss_curr_import_album;
	/*
    jQuery('#rtMedia-upload-button').on('click', function(e) {
          alert();
          console.log(uploaderObj.uploader);
		  var input = document.getElementById(uploaderObj.uploader.id + '_html5'); console.log(input);
		  if (input && !input.disabled) {
		    input.click();
		  } // if
		  e.preventDefault();
		});    */

    jQuery("#rtMedia-upload-button").click(function() {
	    if (/(iphone|ipod|ipad|android|iemobile|webos|fennec|blackberry|kindle|series60|playbook|opera\smini|opera\smobi|opera\stablet|symbianos|palmsource|palmos|blazer|windows\sce|windows\sphone|wp7|bolt|doris|dorothy|gobrowser|iris|maemo|minimo|netfront|semc-browser|skyfire|teashark|teleca|uzardweb|avantgo|docomo|kddi|ddipocket|polaris|eudoraweb|opwv|plink|plucker|pie|xiino|benq|playbook|bb|cricket|dell|bb10|nintendo|up.browser|playstation|tear|mib|obigo|midp|mobile|tablet)/.test(navigator.userAgent.toLowerCase())) {
	    	jQuery("#rtMedia-upload-button").attr('multiple','multiple');
	    	jQuery('div.moxie-shim input[type=file]').attr('multiple','multiple');
	    	jQuery('div.moxie-shim input[type=file]').attr('accept','image/*');
	    	if(/iphone/.test(navigator.userAgent.toLowerCase()) ){
	    		jQuery('div.moxie-shim input[type=file]').trigger('click');
	    	}



        }
	});
	/*
	jQuery( '.rtm-si-import-btn-cancel' ).on('click', function(e){
		alert('a');
		e.preventDefault();

		console.log("rtm-si-import-btn-cancel");
		//jQuery.magnificPopup.close();

		// TODO: Cancel button click
		console.log(jQuery('#rtmedia_uploader_filelist li'));
        jQuery.each(jQuery('#rtmedia_uploader_filelist li'), function(i,v) {
        	console.log(v);
        });
		jQuery('#rtmedia_uploader_filelist li').remove();
		jQuery('#review-album *').remove();
		jQuery('.photo-upload').css('display', 'block');

		setMessage();
		jQuery('#uploadImagesDialog').modal('hide');
	});
    */
	jQuery( '.rtm-sc-import-btn' ).click( function( e ){
		console.log( 'Facebook auth' );
		// Facebook auth
		FB.login( function( response ) {
			if ( response.authResponse ){
				rtm_fb_uid = response.authResponse.userID;
				rtm_fb_accesstoken = response.authResponse.accessToken;
				rtm_ss_init_lightbox();
			} else {
				console.log( 'rtMedia Social Sync: Facebook authorization failed.' );
			}
		},{scope: 'user_photos, user_videos'});
		e.preventDefault();
	});


	// open lightbox and load user's facebook albums
	function rtm_ss_init_lightbox(){

		var parent_div = jQuery( '<div id="rtm-si-container"></div>' );
		var main_div = jQuery( '<div id="rtm-si-media-container"></div>' );
		var sub_div_album =  jQuery( '<div id="rtm-si-album-list"></div>' );
		var sub_div_photo =  jQuery( '<div id="rtm-si-photo-list"></div>' );
		var album_nav = jQuery( '<div class="rtm-si-media-nav">'+ rtmedia_si_js_strings.your_album +'</div>' );
		var loading = jQuery( '<div class="rtm-si-loading"><img src="' + rMedia_loading_media + '" /><p>'+ rtmedia_si_js_strings.importing_from_fb +'</p></div>' );
		var import_option = jQuery( '<div id="rtm-si-import-btn-container"><button id="rtm-si-import-btn" disabled="disabled">Import</button><p class="rtm-si-select-media-notice">*' + rtmedia_si_js_strings.import_notice + '</p></div>' );

		jQuery.magnificPopup.open({
			mainClass: 'rtm-si-lb-container',
			closeOnBgClick: false,
			closeOnContentClick: false,
			items: {
				src: parent_div, // can be a HTML string, jQuery object, or CSS selector
				type: 'inline'
			}
		});
		rtm_si_magnificpopup = jQuery.magnificPopup.instance;

		parent_div.append( main_div );
		main_div.append( loading );
		main_div.append( album_nav );
		main_div.append( sub_div_album );
		main_div.append( sub_div_photo );
		main_div.append( import_option );
		rtm_ss_show_fb_albums();
	}

	jQuery( '.album-ymsmedia-detail' ).click( function( e ){
		console.log( 'rtm_ss_init_lightbox_upload' );
		// rtm_ss_init_lightbox_upload();
		e.preventDefault();
	});

	jQuery( 'body' ).on('click','#open-popup-yms', function( e ){
		console.log("open-popup-yms");
		jQuery('.open-popup-link').trigger('click' );
	});
	// open lightbox
	function rtm_ss_init_lightbox_upload(){
		var parent_div = jQuery( '<div id="rtm-si-container"></div>' );
		var main_div = jQuery( '<div id="rtm-si-media-container"></div>' );
		var sub_div_album =  jQuery( '<div class="clearfix"><ul class="plupload_filelist_content ui-sortable rtm-plupload-list clearfix" id="rtmedia_uploader_filelist"></ul></div>' );
		var sub_div_photo =  jQuery( '<div id="rtm-si-photo-list"></div>' );
		var album_nav = jQuery( '<div class="rtm-si-media-nav-yms fiesta">Upload up to 10 pictures</div>' );
		var album_nav_msg = jQuery( '<div class="rtm-si-media-nav-yms-msg"><span class="rtm-si-fb-album-name">MAXIMUM 10 PICTURE<BR>File size, Maximum 10MB.</span> <label class="rtm-si-sel-all-container-msg"><button id="rtMedia-upload-button" class="rtmedia-upload-input rtmedia-file">From Local folder</button><button id="import-facebook-btn" class="rtm-sc-import-btn">From Facebook</button></label></div> ' );
		var loading = jQuery( '<div class="rtm-si-loading"><img src="' + rMedia_loading_media + '" /><p>'+ rtmedia_si_js_strings.importing_from_fb +'</p></div>' );

		var import_option = jQuery( '<div id="rtm-si-import-btn-container-yms"><button id="rtm-si-import-btn" disabled="disabled">CANCEL</button><button id="rtm-si-import-btn" disabled="disabled">SAVE</button></div>' );

		jQuery.magnificPopup.open({
			mainClass: 'rtm-si-lb-container',
			closeOnBgClick: false,
			closeOnContentClick: false,
			items: {
				src: parent_div, // can be a HTML string, jQuery object, or CSS selector
				type: 'inline'
			}
		});
		rtm_si_magnificpopup = jQuery.magnificPopup.instance;

		parent_div.append( main_div );
		// main_div.append( loading );
		main_div.append( album_nav );
		main_div.append( album_nav_msg );
		main_div.append( sub_div_album );
		// main_div.append( sub_div_photo );
		main_div.append( import_option );
		// setTimeout( function(){ rtm_ss_show_fb_albums(); }, 2000 );
	}

	jQuery('.open-popup-link').magnificPopup({
		mainClass: 'rtm-si-lb-container',
		type:'inline',
		closeOnBgClick: false,
		closeOnContentClick: false,
		showCloseBtn: false,
		midClick: true // Allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source in href.
	});

	function rtm_ss_load_fb_albums(){

	}

	/*
	 return whether response from FB api is valid or not
	 */
	function rtm_ss_is_fb_res_valid( res ){
		return ( typeof res.error == 'undefined' && typeof res.data != 'undefined' && res.data.length > 0 );
	}

	/*
	 return whether there are more media or not from FB api
	 */
	function rtm_ss_fb_res_has_next( res ){
		return ( res.paging != undefined && res.paging.next != undefined  );
	}

	function rtm_ss_get_single_album_li( album, res_cover ){
		images = '';
		if( typeof res_cover.photos != 'undefined' && typeof res_cover.photos.data != 'undefined' && res_cover.photos.data.length > 0 ){
			jQuery.each( res_cover.photos.data, function ( j, fb ){
				last_index = fb.images.length - 1;
				images += '<div class="rtm-ss-album-cover-images"><img src="' + fb.images[last_index].source + '" /></div>';
			});
			li = jQuery( '<li></li>' );
			return li.append( '<input type="checkbox" class="rtm-ss-album-select" /><div data-id="' + album.id + '" data-type="photo-album" data-title="' + album.name + '"><div class="rtm-ss-image-container">' + images + '</div><span>' + album.name + ' (' + res_cover.count + ')</span></div>' );
		}
		console.log( 'get_single_album_li' );
		return '';
	}

	// show user's facebook albums
	function rtm_ss_show_fb_albums(){
		var parent_div = jQuery( '#rtm-si-container' );
		var main_div = jQuery( '#rtm-si-media-container' );
		var sub_div_album =  jQuery( '#rtm-si-album-list' );
		var sub_div_photo =  jQuery( '#rtm-si-photo-list' );
		var album_nav =  jQuery( '.rtm-si-media-nav' );
		var loading = jQuery( '.rtm-si-loading' );
		var import_option = jQuery( '#rtm-si-import-btn-container' );
		var ul = jQuery( '<ul class="rtm-ss-fb-album"></ul>' );

		rtm_ss_is_album = true;
		loading.show();
		sub_div_album.hide();
		sub_div_photo.hide();
		album_nav.hide();
		import_option.hide();
		rtm_si_api_offset = 0;

		fetch = jQuery(".rtm-sc-import-btn").data("value");
		console.log(fetch);
		if(fetch == 'import photo'){
			// fetch user's albums
			FB.api( 'me/albums?limit=' + rtm_si_api_limit, function( res_album ){
				if( rtm_ss_is_fb_res_valid( res_album ) ){
					album_nav.html( '<span class="rtm-si-fb-album-name">' + rtmedia_si_js_strings.your_album + '</span><label class="rtm-si-sel-all-container"><input type="checkbox" id="rtm-si-sel-all">'+ rtmedia_si_js_strings.select_all +'</label>' );
					loading.hide();
					sub_div_album.show();
					album_nav.show();
					sub_div_album.html( ul );
					var offset = 0;

					jQuery.each( res_album.data, function ( i, single_album ){
						offset = parseInt( single_album.count ) - rtm_ss_album_cover_count;
						FB.api( single_album.id + '/?fields=photos.limit(' + rtm_ss_album_cover_count + '){name,id,images},count', function( res_cover ){
							ul.append( rtm_ss_get_single_album_li( single_album, res_cover ) );
						});
					});

					import_option.show();
					if( res_album.paging !== undefined && res_album.paging.next !== undefined ){
						if( jQuery( '#rtm-si-load-more-btn' ).length > 0 ){
							jQuery( '#rtm-si-load-more-btn' ).remove();
						}
						jQuery( '#rtm-si-import-btn' ).before( '<button id="rtm-si-load-more-btn">'+ rtmedia_si_js_strings.load_more +'</button>' );
					}
				} else {
					loading.hide();
					main_div.remove();
					parent_div.append( '<div class="rtm-si-error">'+ rtmedia_si_js_strings.error +'</div>' );
				}
			});
		}

		if(fetch == 'Upload videos'){
			// fetch user's videos
			FB.api( 'me/videos/uploaded?fields=id,description,picture', function( res_video ){
				if( typeof res_video.error != 'undefined' ){
					return;
				}
				if( typeof res_video.data != 'undefined' && res_video.data.length > 0 ){
					album_nav.html( '<span class="rtm-si-fb-album-name">' + rtmedia_si_js_strings.your_album + '</span><label class="rtm-si-sel-all-container"><input type="checkbox" id="rtm-si-sel-all">'+ rtmedia_si_js_strings.select_all +'</label>' );
					loading.hide();
					sub_div_album.show();
					album_nav.show();
					sub_div_album.html( ul );

					var li = jQuery( '<li data-type="video-album" data-id="" data-name="Videos"></li>' );
					li.append( '<div class="rtm-ss-image-container"><img src="' + res_video.data[0].picture + '" /></div><span>'+ rtmedia_si_js_strings.videos +'</span>' );
					ul.append( li );
				}
			});
		}
	}

	// show user's facebook media
	function rtm_ss_show_fb_media( album_id, album_name, media_type ){
		var parent_div = jQuery( '#rtm-si-container' );
		var main_div = jQuery( '#rtm-si-media-container' );
		var sub_div_album =  jQuery( '#rtm-si-album-list' );
		var sub_div_photo =  jQuery( '#rtm-si-photo-list' );
		var album_nav =  jQuery( '.rtm-si-media-nav' );
		var loading = jQuery( '.rtm-si-loading' );
		var import_option = jQuery( '#rtm-si-import-btn-container' );
		var ul = jQuery( '<ul class="rtm-ss-fb-photo"></ul>' );
		var api_call_param;

		rtm_ss_is_album = false;
		loading.html( '<img src="' + rMedia_loading_media + '" /><p>'+ rtmedia_si_js_strings.loading +'</p>' );
		loading.show();
		sub_div_photo.hide();
		sub_div_album.hide();
		album_nav.hide();
		import_option.hide();
		album_nav.html( '<a href="#">'+ rtmedia_si_js_strings.your_album +'</a> &#62; <span class="rtm-si-fb-album-name">' + album_name + '</span><label class="rtm-si-sel-all-container"><input type="checkbox" id="rtm-si-sel-all">'+ rtmedia_si_js_strings.select_all +'</label>');

		if( jQuery( '#rtm-si-load-more-btn' ).length > 0 ){
			jQuery( '.rtm-si-load-more' ).remove();
		}

		rtm_si_api_offset = 0;
		if( media_type == "video" ){
			api_call_param = 'me/videos/uploaded?fields=id,source,description,picture&limit=' + rtm_si_api_limit;
		} else {
			api_call_param = album_id + '/photos?fields=id,name,source,images&limit=' + rtm_si_api_limit;
		}

		FB.api( api_call_param, function( res_media ){
			if( typeof res_media.error != 'undefined' ){
				loading.hide();
				main_div.remove();
				parent_div.append( '<div class="rtm-si-error">'+ rtmedia_si_js_strings.error +'</div>' );
				return;
			}
			if( typeof res_media.data != 'undefined' && res_media.data.length > 0 ){
				loading.hide();
				sub_div_photo.show();
				album_nav.show();
				import_option.show();
				sub_div_photo.html( ul );

				jQuery.each( res_media.data, function ( i, fb ){
					rtm_ss_append_fb_media( ul, fb, media_type );
				});

				if( jQuery( '#rtm-si-load-more-btn' ).length > 0 ){
					jQuery( '#rtm-si-load-more-btn' ).remove();
				}
				if( res_media.paging !== undefined && res_media.paging.next !== undefined  ){
					jQuery( '#rtm-si-import-btn' ).before( '<button id="rtm-si-load-more-btn" data-type="' + media_type + '" data-album-id="' + album_id + '">'+ rtmedia_si_js_strings.load_more +'</button>' );
				}
			}
		});
	}

	// append photos
	function rtm_ss_append_fb_media( ul, fb, media_type ){
		var last_index, img_src;
		var li = jQuery( '<li id="' + fb.id + '"></li>' );
		var desc = ( fb.name == undefined ) ? '' : fb.name;
		var title = fb.source;
		if( media_type == 'video' ){
			img_src = fb.picture;
		} else {
			last_index = fb.images.length - 1;
			img_src = fb.images[ last_index ].source;
		}
		title = title.replace( /^.*\/|\.[^.]*$/g, '' ).substr( 0, title.lastIndexOf( '.' ) );
		li.append( '<div class="rtm-ss-image-container" data-id="' + fb.id + '" data-title="' + title + '" data-date="' + fb.created_time + '" data-desc="' + desc + '" data-src="' + fb.source + '" data-type="' + media_type + '"><img src="' + img_src + '" /></div><span>' + title + '</span>' );
		ul.append( li );
	}

	/*
	 import more album if in queue
	 @var rtm_ss_curr_import_album holds current album index
	 @var rtm_ss_album_array holds all the selected album data
	 */
	function rtm_ss_maybe_import_next_album(){
		if( typeof rtm_ss_album_array[rtm_ss_curr_import_album] != 'undefined' ){
			var album = rtm_ss_album_array[rtm_ss_curr_import_album];
			var data = rtm_ss_album_import_params( album );
			jQuery( '.rtm-ss-album-import-stats' ).text( 'Creating '+ album.title +' album' );
			console.log( 'maybe_import_next_album' );
			jQuery.post( rtmedia_ajax_url, data, function( res ){
				/*
				 From rtMedia 3.8.11 album create response contains json and we are also filtering that output in
				 this plugin and adding our own json. So, for 3.8.11 onwards we need to do "parseJSON" two times.
				 We will identify it by checking certain properties of return json. If it have res.error or
				 res.album set than rtMedia version is greater than 3.8.10.
				 */
				res = jQuery.parseJSON( res );
				if( typeof res.album == "string" ){
					res = jQuery.parseJSON( res.album );
				}
				rtm_ss_album_array[ res.order ].album_id = res.album_id;
				rtm_ss_fetch_fb_single_album( rtm_ss_album_array[ res.order ], true );
			});
			rtm_ss_curr_import_album++;
		} else {
			// show close ligtbox button
			jQuery('.mfp-close' ).show();
		}
	}

	function rtm_ss_import_album_media( media_array, album_id ){
		console.log( 'rtm_ss_import_album_media' );
		var up_params;
		var upload_url = rtMedia_plupload_config.url;
		var upload_count = 0;
		var total_upload = media_array.length;
		var upload_success = 0;

		jQuery( '.rtm-ss-album-import-stats' ).text( 'Importing ' + total_upload + ' media...' );

		// get first activity id
		if( rtm_ss_activity_id == false ){

			var first_media = media_array.pop();
			up_params = rtm_ss_import_album_upload_media_params( first_media );

			// upload media
			var xhr = jQuery.post( upload_url, up_params, function ( res ) {
				if ( res.media_id != null ) {
					rtm_ss_activity_id = res.activity_id;
					rtm_ss_import_album_upload_media_res( res, xhr );
					rtm_ss_import_album_upload_media();
				} else {
					rtm_ss_maybe_import_next_album();
				}
			});

		} else {
			rtm_ss_import_album_upload_media();
		}

		/*
		 prepare upload parameters
		 */
		function rtm_ss_import_album_upload_media_params( single_media ){
			var up_params = {};
			if ( jQuery( "#rt_upload_hf_redirect" ).length > 0 ){
				up_params['redirect'] = 1;
			}
			console.log("upload parameters line 312");
			jQuery( "#rtmedia-uploader-form input[type=hidden]" ).each( function () {
				up_params[jQuery( this ).attr( "name" )] = jQuery( this ).val();
			} );
			up_params['album_id'] = album_id;
			up_params['mode'] = 'rtm_ss_upload';
			up_params['src'] = single_media.src;
			up_params['description'] = single_media.desc;
			up_params['title'] = single_media.title;
			up_params['rtm_ss_fb_id'] = single_media.fb_id;

			var context_data = rtm_ss_album_import_get_context();

			// set context values in ajax parameters
			if( typeof context_data.context != 'undefined' ){
				up_params['context'] = context_data.context;
				up_params['context_id'] = context_data.context_id;
			}

			if( rtm_ss_activity_id != false ){
				up_params['activity_id'] = rtm_ss_activity_id;
			}

			return up_params;
		}

		/*
		 handle upload response
		 */
		function rtm_ss_import_album_upload_media_res( res, xhr ){
			upload_count++;
			if ( res.media_id != null ) {
				upload_success++;
				jQuery( '.rtm-ss-album-import-stats' ).text( upload_success + ' of ' + total_upload + ' imported successfully' );
				rtMediaHook.call( 'rtmedia_js_after_file_upload', [ '', '', xhr.responseText ] );
			}
			if( upload_count == total_upload ){
				var upload_fail = total_upload - upload_success;
				if( upload_fail > 0 ){
					jQuery( '.rtm-ss-album-import-stats' ).text( upload_success + ' media imported successfully and ' + upload_fail + ' media failed to import.' );
				} else {
					jQuery( '.rtm-ss-album-import-stats' ).text( 'All media imported successfully.' );
				}
				rtm_ss_maybe_import_next_album();
			}
		}

		/*
		 upload media of album
		 */
		function rtm_ss_import_album_upload_media(){
			jQuery.each( media_array, function( i, single_media ){
				up_params = rtm_ss_import_album_upload_media_params( single_media );
				// upload media
				var xhr = jQuery.post( upload_url, up_params, function ( res ) {
					rtm_ss_import_album_upload_media_res( res, xhr );
				});
			});
		}
	}

	/*
	 fetch album data from Facebook
	 */
	function rtm_ss_fetch_fb_single_album( album_data, initialise_offset ){
		var desc, title, img_src, data;

		if( initialise_offset ){
			rtm_si_api_offset = 0;
		} else {
			rtm_si_api_offset+= rtm_si_api_limit;
		}

		api_call_param = album_data.id +'/photos?fields=id,name,images&limit='+rtm_si_api_limit;

		jQuery( '.rtm-ss-album-import-stats' ).text( 'Fetching media from '+ album_data.title +' album' );

		FB.api( api_call_param, function( res_media ){
			if( rtm_ss_is_fb_res_valid( res_media ) ){
				rtm_ss_media_array = [];
				jQuery.each( res_media.data, function( i, res ){
					desc = ( res.name == undefined ) ? '' : res.name;
					title = ( res.source == undefined ) ? '' : res.source;
					title = title.replace( /^.*\/|\.[^.]*$/g, '' ).substr( 0, title.lastIndexOf( '.' ) );
					img_src = res.images[0].source;
					data = {
						'src' : img_src,
						'title' : title,
						'desc' : desc,
						'fb_id' : res.id
					};
					rtm_ss_media_array.push( data );
				});
				if( rtm_ss_fb_res_has_next( res_media ) ){
					rtm_ss_fetch_fb_single_album( album_data, false );
				} else {
					rtm_ss_import_album_media( rtm_ss_media_array, album_data.album_id );
				}
			} else {

			}
		});
	}

	/*
	 get context data for album import
	 */
	function rtm_ss_album_import_get_context(){
		var context_data = {};
		console.log("rtm_ss_album_import_get_context line 421");
		var context_type_el = jQuery( '.rtmedia-uploader' ).find( 'input[name=rtm_ss_context_type]' );
		var context_id_el = jQuery( '.rtmedia-uploader' ).find( 'input[name=rtm_ss_context_id]' );

		if( context_type_el.val() != undefined ){
			context_data.context = context_type_el.val();
		}
		if( context_id_el.val() != undefined ){
			context_data.context_id = context_id_el.val();
		}

		return context_data;
	}

	/*
	 generate create album ajax parameters
	 */
	function rtm_ss_album_import_params( album ){
		// create album
		var data = {
			action: 'rtmedia_create_album',
			name: album.title,
			rtm_ss_fb_id: album.id,
			create_album_nonce: jQuery( '#rtm_ss_create_album_nonce' ).val(),
			order: rtm_ss_curr_import_album
		};

		var context_data = rtm_ss_album_import_get_context();

		// set context values in ajax parameters
		if( typeof context_data.context != 'undefined' ){
			data.context = context_data.context;
			data.context_id = context_data.context_id;
		}
		console.log("create album");
		console.log(data);
		return data;
	}

	// show photos of clicked album
	jQuery( 'body' ).on( 'click', 'ul.rtm-ss-fb-album li > div', function( e ){
		if( jQuery( this ).parent().data( 'type' ) == 'video-album' ){
			rtm_ss_show_fb_media( jQuery( this ).data( 'id' ), jQuery( this ).data( 'title' ), 'video' );
		} else {
			rtm_ss_show_fb_media( jQuery( this ).data( 'id' ), jQuery( this ).data( 'title' ), 'photo' );
		}
		e.preventDefault();
	});

	// select clicked photo
	jQuery( 'body' ).on( 'click', 'ul.rtm-ss-fb-photo li', function( e ){
		if( ! jQuery( this ).hasClass( 'selected' ) ){
			jQuery( this ).addClass( 'selected' );
			jQuery( '#rtm-si-import-btn' ).prop( 'disabled', false );
		} else {
			jQuery( this ).removeClass( 'selected' );
			if( jQuery( 'ul.rtm-ss-fb-photo li.selected' ).length == 0 ){
				jQuery( '#rtm-si-import-btn' ).prop( 'disabled', true );
			}
		}
		e.preventDefault();
	});

	// select/deselect all
	jQuery( 'body' ).on( 'click', '#rtm-si-sel-all', function(){
		if( jQuery( this ).is( ':checked' ) ){
			// if photo gallery is visible than selcect all photos otherwise go for albums
			if( jQuery( 'ul.rtm-ss-fb-photo li' ).is( ':visible' ) ){
				jQuery( 'ul.rtm-ss-fb-photo li' ).addClass( 'selected' );

			} else {
				jQuery( 'ul.rtm-ss-fb-album li' ).not( '[data-type=video-album]' ).addClass( 'selected' );
				jQuery( 'ul.rtm-ss-fb-album li .rtm-ss-album-select' ).attr('checked', true );
			}
			jQuery( '#rtm-si-import-btn').prop( 'disabled', false );
		} else {
			if( jQuery( 'ul.rtm-ss-fb-photo li' ).is( ':visible' ) ){
				jQuery( 'ul.rtm-ss-fb-photo li' ).removeClass( 'selected' );
			} else {
				jQuery( 'ul.rtm-ss-fb-album li' ).not( '[data-type=video-album]' ).removeClass( 'selected' );
				jQuery( 'ul.rtm-ss-fb-album li .rtm-ss-album-select' ).attr('checked', false );
			}
			jQuery( '#rtm-si-import-btn').prop( 'disabled', true );
		}
	});

	// show albums
	jQuery( 'body' ).on( 'click', '.rtm-si-media-nav a', function( e ){
		rtm_ss_show_fb_albums();
		e.preventDefault();
	});

	// select/deselect single album
	jQuery( 'body' ).on( 'click', '.rtm-ss-album-select', function(){
		if( this.checked ){
			jQuery( this ).parent().addClass( 'selected' );
			jQuery( '#rtm-si-import-btn').prop( 'disabled', false );
		} else {
			jQuery( this ).parent().removeClass( 'selected' );
			if( jQuery( '.rtm-ss-fb-album .rtm-ss-album-select:checked' ).length == 0 ){
				jQuery( '#rtm-si-import-btn').prop( 'disabled', true );
			}
		}
	});

	// load more albums
	jQuery( 'body' ).on( 'click', '#rtm-si-load-more-btn', function(){
		var parent_div = jQuery( '#rtm-si-container' );
		var main_div = jQuery( '#rtm-si-media-container' );
		var ul, api_call_param;
		var that = this;

		rtm_si_api_offset+= rtm_si_api_limit;

		if( rtm_ss_is_album ){
			ul = jQuery( '.rtm-ss-fb-album' );

			FB.api( 'me/albums?limit=' + rtm_si_api_limit + '&offset=' + rtm_si_api_offset, function( res_album ){
				if( typeof res_album.error != 'undefined' ){
					main_div.remove();
					parent_div.append( '<div class="rtm-si-error">'+ rtmedia_si_js_strings.error +'</div>' );
					return;
				}
				if( typeof res_album.data != 'undefined' && res_album.data.length > 0 ){
					jQuery.each( res_album.data, function ( i, single_album ){
						offset = parseInt( single_album.count ) - rtm_ss_album_cover_count;
						FB.api( single_album.id + '/?fields=photos.limit(' + rtm_ss_album_cover_count + '){name,id,images},count', function( res_cover ){
							ul.append( rtm_ss_get_single_album_li( single_album, res_cover ) );
						});
					});
					if( res_album.paging === undefined || res_album.paging.next === undefined ){
						jQuery( that ).prop( 'disabled', true );
					}
				}
			});

		} else {
			ul = jQuery( '.rtm-ss-fb-photo' );

			if( jQuery( this ).data( 'type' ) == "video" ){
				api_call_param = '/me/videos/uploaded?limit=' + rtm_si_api_limit + '&offset=' + rtm_si_api_offset;
			} else {
				api_call_param = jQuery( this ).data( 'album-id' ) +'/photos?limit=' + rtm_si_api_limit + '&offset=' + rtm_si_api_offset;
			}

			FB.api( api_call_param, function( res_media ){
				if( typeof res_media.error != 'undefined' ){
					main_div.remove();
					parent_div.append( '<div class="rtm-si-error">'+ rtmedia_si_js_strings.error +'</div>' );
					return;
				}
				if( typeof res_media.data != 'undefined' && res_media.data.length > 0 ){
					jQuery.each( res_media.data, function ( i, fb ){
						rtm_ss_append_fb_media( ul, fb, jQuery( that).data( 'type' ) );
					});
					if( res_media.paging === undefined || res_media.paging.next === undefined  ){
						jQuery( that ).prop( 'disabled', true );
					}
				}
			});
		}
	});

	jQuery( 'body' ).on( "click", "#rtmedia_uploader_filelist li",function(e){
		// console.log(jQuery( this ));
		jQuery( this ).parent().children("li").removeClass( 'selected' );
		jQuery(".product_image_gallery").remove();
		jQuery( this ).addClass( 'selected' );

		if(jQuery( '#rtmedia_uploader_filelist' ).find( '.selected' ).length > 0){
			// console.log("da chon hinh");
			jQuery( '#msg_cover' ).text("Album cover set");

		}else{
			// console.log("chua chon hinh");
			jQuery( '#msg_cover' ).text("Select ther album cover by clicking on an image");
		}
		jQuery( '.start-media-upload' ).removeClass("yms-disable");
		featured_id = jQuery( this ).find('.yms_image_featured').attr("value");
		// console.log(featured_id);
		if(featured_id != ''){
			jQuery( this ).append( '<input type="hidden" class="product_image_gallery" name="product_image_featured" value="'+featured_id+'">' );
		}else{
			jQuery( this ).append( '<input type="hidden" class="product_image_gallery" name="product_image_featured" value="">' );
		}


		e.preventDefault();
	});

	jQuery( 'body' ).on( "click", ".plupload_delete",function(e){
        alert('ya ya');
		// jQuery(this).parent().parents( 'li' ).remove();
		var that = jQuery( this );
		confirm("This media is uploaded. Are you sure you want to delete this media?", function () {
			// console.log("AAAAAAAAAAAAAAAAAAAaa");
			featured_id = jQuery( that ).parent().parents( 'li' ).children('.image_featured ').children('input[name=yms_image_featured]').val();
			alert(featured_id);
			jQuery( '#ymsmedia ' ).children('input[value='+featured_id+']').remove();
			jQuery(that).parent().parents( 'li' ).remove();
			// console.log(jQuery( that ).html());
			if(jQuery( '#rtmedia_uploader_filelist' ).find( '.selected' ).length > 0){
				// console.log("da chon hinh");
				jQuery( '#msg_cover' ).text("Album cover set");
			}else{
				// console.log("chua chon hinh");
				jQuery( '#msg_cover' ).text("Please click on picture to select Album Cover");
			}
			if(jQuery( '#rtmedia_uploader_filelist' ).children( 'li' ).length==0){
				/*jQuery( '#msg_cover' ).text("");*/
				jQuery('.image_upload_title').text('STEP 1: UPLOAD PHOTOS');
				jQuery( '#msg_cover' ).text("You can upload maximum 10 pictures. Maximum file size 10mB.").removeClass('blue');
				jQuery( '.start-media-upload' ).addClass("yms-disable");
			}
			setMessage();
		});
		/*
		 if ( confirm( "This media is uploaded. Are you sure you want to delete this media?" ) ) {
		 featured_id = jQuery( this ).parent().parents( 'li' ).children('.image_featured ').children('input[name=yms_image_featured]').val();
		 // console.log(jQuery( this ).parent().parents( 'li' ).children('.image_featured ').children('input[name=yms_image_featured]').val());
		 jQuery( '#ymsmedia ' ).children('input[value='+featured_id+']').remove();
		 jQuery(this).parent().parents( 'li' ).remove();
		 // alert("rtmedia_delete_uploaded_media ok");
		 // var nonce = $( '#rtmedia-upload-container #rtmedia_media_delete_nonce' ).val();
		 // var media_id = $( this ).attr( 'id' );
		 // var data = {
		 // action: 'delete_uploaded_media',
		 // nonce: nonce,
		 // media_id: media_id
		 // }

		 // $.post( ajaxurl, data, function ( response ) {
		 // if ( response == '1' ) {
		 // that.closest( 'tr' ).remove();
		 // $( '#' + media_id ).remove();
		 // }
		 // } );
		 if(jQuery( '#rtmedia_uploader_filelist' ).find( '.selected' ).length > 0){
		 // console.log("da chon hinh");
		 jQuery( '#msg_cover' ).text("Album cover set");
		 }else{
		 // console.log("chua chon hinh");
		 jQuery( '#msg_cover' ).text("Select ther album cover by clicking on an image");
		 }
		 if(jQuery( '#rtmedia_uploader_filelist' ).children( 'li' ).length==0){
		 jQuery( '#msg_cover' ).text("");
		 jQuery( '.start-media-upload' ).addClass("yms-disable");
		 }
		 }
		 */
		return false;
	});

	// Add selected media in queue and if it's album than import whole album
	jQuery( 'body' ).on( 'click', '#rtm-si-import-btn', function( e ){
		rtm_ss_activity_id = false;
		// check if album import
		if( rtm_ss_is_album ){
			console.log("check if album import");
			// reset album array, current album index and media array
			rtm_ss_album_array = [];
			rtm_ss_curr_import_album = 0;
			rtm_ss_media_array = [];

			// hide close lightbox button
			jQuery('.mfp-close' ).hide();

			// add import screen div
			jQuery( '#rtm-si-container' ).after( '<div id="rtm-ss-import-screen"></div>' );

			// generate import album array
			jQuery.each( jQuery('.rtm-ss-fb-album li.selected'), function( i, li ){
				curr_div = jQuery( li ).children( 'div' );
				single_album = {};
				single_album.id = jQuery( curr_div ).data( 'id' );
				single_album.title = jQuery( curr_div ).data( 'title' );
				rtm_ss_album_array.push( single_album );
			} );

			jQuery( '#rtm-ss-import-screen' ).append( '<p class="rtm-ss-album-import-stats"></p>' );
			rtm_ss_maybe_import_next_album();
		} else {
			console.log("else check if album import");
			if(jQuery( '#rtmedia_uploader_filelist' ).children( 'li' ).length + jQuery( 'ul.rtm-ss-fb-photo li.selected' ).length > 10){
				// alert("MAXIMUM 10 PICTURE");
				init_info_window('You can select only 10 photos', 'danger');
				//jQuery("#msg-max").modal();
				return jQuery( '.open-popup-link' ).trigger( 'click' ); ;
			}
			jQuery.each( jQuery( 'ul.rtm-ss-fb-photo li.selected' ), function ( i, li ){
				curr_div = jQuery( li ).find( '.rtm-ss-image-container');
				id = jQuery( curr_div ).data( 'id' );

				rtmedia_ss_media_preview_error_ui( jQuery( curr_div ) );

				rtm_si_upload_total++;

				// handle remove media from upload queue
				jQuery( '#rtm-ss-upload-' + id + ' .plupload_delete' ).click( function(){
					// jQuery(this).parent().parents( 'li' ).remove();
				});
			});
			if( jQuery( 'ul.rtm-ss-fb-photo li.selected' ).length > 0 ){
				rtm_ss_media_upload = true;

				if( typeof rtmedia_direct_upload_enabled != 'undefined' && rtmedia_direct_upload_enabled == '1' ) {
					// jQuery( '.start-media-upload' ).hide();
					jQuery( '.start-media-upload' ).trigger( 'click' );
				} else {
					jQuery( '.start-media-upload' ).show();
				}
			}
			rtm_si_magnificpopup.close();
			jQuery( '.open-popup-link' ).trigger( 'click' );
			if ( jQuery( '#rtmedia_uploader_filelist' ).children( 'li' ).length > 0 ) {
				var allow_upload = rtMediaHook.call( 'rtmedia_js_upload_file', true );

				if ( allow_upload == false ) {
					return false;
				}
				uploaderObj.uploadFiles();
				jQuery(".plupload_file_action").html('<div class="plupload_action_icon ui-icon plupload_delete"><span class="remove-from-queue ico ico-remove"></span></div>');
				if(jQuery( '#rtmedia_uploader_filelist' ).find( '.selected' ).length > 0){
					// console.log("da chon hinh");
					jQuery( '#msg_cover' ).text("Album cover set");
				}else{
					// console.log("chua chon hinh");
					jQuery( '#msg_cover' ).text("Select ther album cover by clicking on an image");
				}
				jQuery( '.start-media-upload' ).removeClass("yms-disable");
			}else{
				jQuery( '.start-media-upload' ).addClass("yms-disable");
			}
		}
	});

	rtMediaHook.register(
		'rtmedia_js_after_files_uploaded',
		function () {
			//console.log( 'rtmedia_js_after_files_uploaded' );

			//console.log(rtMedia_plupload_config);

			if ( rtm_ss_media_upload && typeof rtMedia_plupload_config == "object" && jQuery( '#rtmedia_uploader_filelist .rtm-ss-upload-queue' ).length > 0 ) {
				upload_url = rtMedia_plupload_config.url;

				/*
				 prepare upload parameters
				 */
				function rtm_ss_get_upload_params( media_td ){
					var up_params = {};
					if ( jQuery( "#rt_upload_hf_redirect" ).length > 0 )
						up_params['redirect'] = 1;
					jQuery( "#rtmedia-uploader-form input[type=hidden]" ).each( function () {
						up_params[jQuery( this ).attr( "name" )] = jQuery( this ).val();
					} );
					up_params['activity_id'] = activity_id;
					if ( jQuery( '#rtmedia-uploader-form .rtmedia-user-album-list' ).length > 0 ) {
						album_id = jQuery( '#rtmedia-uploader-form .rtmedia-user-album-list' ).find( ":selected" ).val();
					} else if ( jQuery( '#rtmedia-uploader-form .rtmedia-current-album' ).length > 0 ) {
						album_id = jQuery( '#rtmedia-uploader-form .rtmedia-current-album' ).val();
					}
					up_params['album_id'] = album_id;
					up_params['privacy'] = privacy;
					up_params['mode'] = 'rtm_ss_upload';
					up_params['src'] = jQuery( media_td ).data( 'src' );
					up_params['description'] = jQuery( media_td ).data( 'desc' );
					up_params['title'] = jQuery( media_td ).find( '.plupload_file_name_wrapper').text().split('.')[0];
					up_params['rtm_ss_fb_id'] = jQuery( media_td ).data( 'id' );

					if( rtm_ss_activity_id !== false ){
						up_params['activity_id'] = rtm_ss_activity_id;
					}

					return up_params;
				}

				/*
				 Upload media from queue
				 */
				function rtm_ss_upload_media(){
					// loop through upload queue to upload
					jQuery.each( jQuery( '#rtmedia_uploader_filelist .rtm-ss-upload-queue' ), function( i, media_td ){
						current_td = jQuery( media_td );
						var up_params = rtm_ss_get_upload_params( media_td );
						current_td.removeClass();
						jQuery( media_td ).find( ' .plupload_file_status' ).html( '<div class="plupload_file_progress ui-widget-header" style="width: 100%;"></div>' );
						current_td.addClass( 'upload-progress' );
						// console.log( 'rtm_ss_upload_media' );
						// console.log( up_params );
						// upload media

						var xhr = jQuery.post( upload_url, up_params, function ( res ) {
							rtm_ss_upload_media_res( res, xhr );
							if ( res.media_id != null ) {
								jQuery("#ymsmedia").append('<input type="hidden" id="product_image_gallery" name="product_image_gallery[]" value="'+res.media_id+'">');
							}
						} );
					});
				}

				/*
				 handle upload response
				 */
				function rtm_ss_upload_media_res( res, xhr ){
					if ( res.media_id != null ) {

						current_tr = '#rtm-ss-upload-' + res.rtm_ss_fb_id;

						rtMediaHook.call( 'rtmedia_js_after_file_upload', [ '', '', xhr.responseText ] );

						// set upload limit parameters
						if( typeof( rtMedia_plupload_config.rtmedia_pro_upload_limits_current_stats ) != "undefined" ) {
							rtMedia_plupload_config.rtmedia_pro_upload_limits_current_stats.files.daily = ( parseInt( rtMedia_plupload_config.rtmedia_pro_upload_limits_current_stats.files.daily ) + 1 ).toString();
							rtMedia_plupload_config.rtmedia_pro_upload_limits_current_stats.files.monthly = ( parseInt( rtMedia_plupload_config.rtmedia_pro_upload_limits_current_stats.files.monthly ) + 1 ).toString();
							rtMedia_plupload_config.rtmedia_pro_upload_limits_current_stats.files.lifetime = ( parseInt( rtMedia_plupload_config.rtmedia_pro_upload_limits_current_stats.files.lifetime ) + 1 ).toString();
						}

						jQuery( current_tr ).removeClass();
						jQuery( current_tr ).addClass( 'upload-success' );
						// jQuery( current_tr +' .plupload_file_status' ).html( rtmedia_uploaded_msg );
						// jQuery( current_tr +' .plupload_file_status' ).html( "" );
						jQuery( current_tr ).attr("myUrl",res.cover_art);
						jQuery( current_tr +' .image_featured' ).html( '<input type="hidden" class="yms_image_featured" name="yms_image_featured" value="'+res.media_id+'">' );
						jQuery( current_tr + " .plupload_file_thumb" ).html( '<img src="'+res.cover_art+'" height="110" width="110">' );
						// jQuery( current_tr ).append( '<input type="hidden" id="product_image_gallery" name="product_image_featured[]" value="'+res.media_id+'">' );
						jQuery( current_tr + ' input[name=product_image_featured]' ).val(res.media_id);//
						// console.log(jQuery( current_tr ).html());
					} else {
						alert( 'Fail to upload file from URL.' );
						jQuery( current_tr ).removeClass();
						jQuery( current_tr ).addClass( 'upload-error' );
						// jQuery( current_tr + ' .plupload_file_status' ).html( rtmedia_upload_failed_msg );
						// jQuery( current_tr + ' .plupload_file_status' ).html( "" );
					}

					rtm_si_upload_total--;
					if( rtm_si_upload_total == 0 ){
						rtm_ss_media_upload = false;
						// jQuery( '#rtmedia_uploader_filelist li' ).remove();
						// reload media gallery
						rtm_ss_reload_media_gallery();
					}
				}

				// set upload parameters
				var privacy = jQuery( "#rtm-file_upload-ui select.privacy" ).val();
				var album_id = '';
				// get first activity id
				if( rtm_ss_activity_id == false ){
					var media_td = jQuery( '#rtmedia_uploader_filelist .rtm-ss-upload-queue' )[0];
					var up_params = rtm_ss_get_upload_params( media_td );
					current_td = jQuery( media_td );
					current_td.removeClass();
					jQuery( media_td ).find( ' .plupload_file_status' ).html( '<div class="plupload_file_progress ui-widget-header" style="width: 100%;"></div>' );
					current_td.addClass( 'upload-progress' );

					// upload media
					var xhr = jQuery.post( upload_url, up_params, function ( res ) {
						if ( res.media_id != null ) {
							console.log("upload media line 749");
							jQuery("#ymsmedia").append('<input type="hidden" id="product_image_gallery" name="product_image_gallery[]" value="'+res.media_id+'">');
							// console.log(res);
							rtm_ss_activity_id = res.activity_id;
							rtm_ss_upload_media_res( res, xhr );
							rtm_ss_upload_media();
						}
					});
				} else {
					rtm_ss_upload_media();
				}

			}
			return true;
		}
	);

	function rtm_ss_reload_media_gallery(){
		if( typeof galleryObj == 'object' ){
			galleryObj.reloadView();
		}
	}
});

function rtmedia_ss_media_preview_error_ui( curr_div ) {
	var tr = '';
	var id = curr_div.data( 'id' );
	var title = curr_div.data( 'title' );
	var desc = curr_div.data( 'desc' );
	var src = curr_div.data( 'src' );
	var date = curr_div.data( 'date' );
	var type = curr_div.data( 'type' );

	if( jQuery( 'li#rtm-ss-upload-' + id ).length === 0 ) {
		tr = "<li title='Set as album cover' class='plupload_file ui-state-default rtm-ss-upload-queue' id='rtm-ss-upload-" + id + "' data-id='" + id + "' data-desc='" + desc + "' data-src='" + src + "' data-date='" + date + "'>";
		tr += "<div id='file_thumb_" + id + "' class='plupload_file_thumb'></div>";
		tr += "<div class='plupload_file_status'>";
		tr += "</div>";
		tr += "<div class='plupload_file_name' title='" + title + "'>";
		tr += '<span class="plupload_file_name_wrapper">' + title + '</span>';
		tr += '<span id="label_' + id + '" class="dashicons dashicons-edit rtmicon" title="Edit File Name"></span>';
		tr += "</div>";
		tr += "<div class='plupload_file_action'>";
		tr += "<div class='plupload_action_icon ui-icon plupload_delete'>";
		tr += '<span class="remove-from-queue ico ico-remove"></span>';
		tr += "</div>";
		tr += "</div>";
		tr += "<div class='plupload_file_size'></div>";
		tr += "<div class='plupload_file_fields'></div>";
		tr += "<div class='image_featured'></div>";
		tr += "</li>";

		jQuery( '#rtmedia_uploader_filelist' ).append( tr );

		jQuery( '<img src="' + rtmedia_media_thumbs[ type ] + '" />' ).appendTo( '#file_thumb_' + id );

		jQuery( "#label_" + id ).click( function ( e ) {
			e.preventDefault();

			rtm_file_label = this;
			rtm_file_title_input = '#text_' + id;
			rtm_file_title_save = '#save_' + id;

			jQuery( rtm_file_label ).hide();
			jQuery( rtm_file_label ).siblings( '.plupload_file_name_wrapper' ).hide();

			// show/create text box to edit media title
			if( jQuery( rtm_file_title_input ).length === 0 ) {
				jQuery( rtm_file_label ).parent( '.plupload_file_name' ).prepend( '<input type="text" id="text_' + id + '" value="' + title + '" style="width: 75%;" /><span id="save_' + id + '" title="Save Change" class="rtmicon dashicons dashicons-yes"></span>' );
			} else {
				jQuery( rtm_file_title_input ).show();
				jQuery( rtm_file_title_save ).show();
			}

			jQuery( rtm_file_title_input ).focus();

			// set new media title
			jQuery( rtm_file_title_input ).keyup( function( e ) {
				if( this.value != '' ) {
					title = this.value;
				}

				if( e.keyCode == '13' ) {
					return false;
				}
			} );

			// hide input box for media title and show label of media title
			jQuery( rtm_file_title_input ).blur( function( e ) {
				if ( this.value != '' ) {
					jQuery( rtm_file_title_input ).hide();
					jQuery( rtm_file_title_save ).hide();
					jQuery( rtm_file_label ).siblings( '.plupload_file_name_wrapper' ).text( title );
				}

				jQuery( rtm_file_label ).siblings( '.plupload_file_name_wrapper' ).show();
				jQuery( rtm_file_label ).show();
			} );
		} );
	}
}
