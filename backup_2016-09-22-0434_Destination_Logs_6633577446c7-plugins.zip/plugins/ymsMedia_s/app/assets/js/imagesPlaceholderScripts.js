$(function(){

    // TODO: Call placeholder generate function
    $('#uploadImagesDialog').modal('show.bs.modal', function(e){
        generateImagesPlaceholder();

        console.log('1');
    });

});

function generateImagesPlaceholder(){
    var readyImages = jQuery('#rtmedia_uploader_filelist li.plupload_file');
    var listElementsCount = jQuery('#rtmedia_uploader_filelist li').length;
    var maxImagesCount = 10;

    if(readyImages.length == maxImagesCount) return false;

    for(var i=maxImagesCount; i<readyImages.length; i--){
        var placeholderTemplate = '<li class="image-placeholder image-placeholder-' + i + '"></li>';
        console.log('template - ' + i + ': ' + placeholderTemplate);
    }
}