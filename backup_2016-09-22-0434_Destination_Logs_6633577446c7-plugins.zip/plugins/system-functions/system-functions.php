<?php

/**
 * Plugin Name: System functions
 * Description: Necessary adjustments
 */


// Get user avatar shortcode

function dl_get_user_avatar() {
	global $wpdb;
	$user_id = do_shortcode('[wpv-user field="ID"]');
	$results = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'usermeta WHERE user_id = ' . $user_id . ' AND meta_key = "wsl_current_user_image"', ARRAY_N );
	$current_avatar = $results[0][count($results)-1];

	if (empty($results)) {
	    return '<img src="' . get_avatar_url( $user_id, array('size' => 120)) . '">';
	} else {
	    return '<img src="' . $current_avatar . '">';
	}  
}
add_shortcode( 'avatar', 'dl_get_user_avatar' );      

function dl_get_user_avatar_loop() {
	global $wpdb;
	$user_id = get_the_author_meta('ID');
	$results = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'usermeta WHERE user_id = ' . $user_id . ' AND meta_key = "wsl_current_user_image"', ARRAY_N );
	// $current_avatar = $results[0][count($results)-1];
	if (empty($results)) {
	    return '<img src="' . get_avatar_url( $user_id, array('size' => 120)) . '">';
	} else {
	    return '<img src="' . $results[0][0] . '">';
	}  
}
add_shortcode( 'avatar_loop', 'dl_get_user_avatar_loop' );    


// Get date for front-end
function dl_get_log_date() {
	$date = do_shortcode('[types field="departure-date"][/types]');
	return date('M Y', strtotime($date)); 
}
add_shortcode( 'log_date', 'dl_get_log_date' );      

// Disable admin bar
show_admin_bar(false);

// Display three thumbs on home page
// function dl_display_three_pics() {
// 	global $wpdb;
// 	$post_id = do_shortcode('[wpv-post-id]');

// 	$results = $wpdb->get_results( 'SELECT meta_value FROM wp_postmeta WHERE post_id = ' . $post_id  . ' AND meta_key = "_product_image_gallery"', ARRAY_N );
// 	$ids = explode(',', $results[0][0]);
// 	$sliced_array = array_slice($ids, 0, 3);

// 	$output = '';
// 	foreach ($sliced_array as $value) {
// 		if ($value > 0) {
// 			// $output .= $value . ' ';
// 			$url = $wpdb->get_results( 'SELECT meta_value FROM wp_postmeta WHERE post_id = ' . $value  . ' AND meta_key = "_wp_attached_file"', ARRAY_N );
// 			$output .= '<div class="home-thumb" style="background-image:url(/wp-content/uploads/' . $url[0][0] . ');"></div>';
// 		}
// 	}

// 	return $output;
// }
// add_shortcode( 'three_pics', 'dl_display_three_pics' );  


// Display three thumbs on home page

function dl_display_three_thumbs() {
	global $wpdb;
	$post_id = do_shortcode('[wpv-post-id]');

	$results = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'postmeta WHERE post_id = ' . $post_id  . ' AND meta_key = "_product_image_gallery"', ARRAY_N );
	if (empty ($results)) {
		return "No images uploaded";
	}

	$ids = explode(',', $results[0][0]);
	$number = count($ids) - 4;
	$featured_id = do_shortcode('[wpv-post-featured-image size="full" output="id" id="' . $post_id . '"]');
	$key = array_search($featured_id, $ids); 
	unset($ids[$key]);	
	
	$sliced_array = array_slice($ids, 0);
	$output = '';
	$i = 1;
	foreach ($sliced_array as $value) {
		if ($value > 0) {
			// $output .= $value . ' ';
			$url = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'postmeta WHERE post_id = ' . $value  . ' AND meta_key = "_wp_attached_file"', ARRAY_N );
			$thumb_url = explode(".", $url[0][0]);
			$extension = array_pop($thumb_url);
			$thumb_url = implode(".", $thumb_url);
			$fullsize_img_url = $thumb_url . '.' . $extension;
			$thumb_url = $thumb_url . '-150x150.' . $extension;
			// $output .= '<div class="home-thumb" style="background-image:url(/wp-content/uploads/' . $url[0][0] . ');"></div>';
			if($i < 4){
				$output .= '<a href="/wp-content/uploads/' . $fullsize_img_url . '" class="featured-thumb fancybox" rel="gallery-' . $post_id . '"><img src="/wp-content/uploads/' . $thumb_url . '" alt="Image description" />';
				if($i == 3 && $number > 0) $output .= '<span class="counter">+' . $number . '</span>';
				$output .= '</a>';
			} else {
				$output .= '<a href="/wp-content/uploads/' . $fullsize_img_url . '" class="featured-thumb fancybox hide" rel="gallery-' . $post_id . '"></a>';
			}
			
		}
	$i++;
	}

	return $output;
	// return "hi";
}
add_shortcode( 'three_thumbs', 'dl_display_three_thumbs' );  

// Big Featured image shortcode

function dl_display_featured_image() {
	$url = do_shortcode('[wpv-post-featured-image size="large" output="url"]');
	$featured_url = explode(".", $url);
	$extension = array_pop($featured_url);
	$featured_url = implode(".", $featured_url);
	$featured_url = $featured_url . '-600x340.' . $extension;
	if (file_exists($featured_url)) {
		return $featured_url;
	}
	return $url;
}
add_shortcode( 'featured_image', 'dl_display_featured_image' ); 


// REL for Featured image
function dl_display_image_rel() {
	global $wpdb;
	$post_id = do_shortcode('[wpv-post-id]');
	$rel = "gallery-".$post_id;
	return $rel;
}
add_shortcode( 'featured_image_rel', 'dl_display_image_rel' ); 

// Medium featured image shortcode 

function dl_display_medium_featured_image() {
	$url = do_shortcode('[wpv-post-featured-image size="large" output="url"]');
	$featured_url = explode(".", $url);
	$extension = array_pop($featured_url);
	$featured_url = implode(".", $featured_url);
	$featured_url = $featured_url . '-380x200.' . $extension;
	if (file_exists($featured_url)) {
		return $featured_url;
	}
	return $url;
}
add_shortcode( 'medium_featured_image', 'dl_display_medium_featured_image' );


// Airline shortcode

function dl_display_airline() {
	$title = '';
	$list = do_shortcode('[types field="transport"][/types]');
	$list = json_decode($list);	
	if (empty($list)) {
		return "Not specified";
	}
	foreach ($list as $transport) {
		if ($transport->type == "airline") {
			$post = get_post($transport->id);
			$title = $post->post_title;
		 	
	 	}		
	}
	return $title;
}	
add_shortcode( 'airline', 'dl_display_airline' ); 

// Display user videos
// TODO: dl_display_user_videos not supported for new design
function dl_display_user_videos(){
	$result = '';
	$post_id = do_shortcode('[wpv-post-id]');
	$firstVideo = get_post_meta($post_id, 'wpcf-video_1');
	$secondVideo = get_post_meta($post_id, 'wpcf-video_2');

	if(!$firstVideo || !$secondVideo) return false;

	$result .= '<div class="videos bdfiesta clearfix">';
	if($firstVideo) $result .= '<a style="width: 750px;display: none;" class="fancybox" rel="gallery-' . $post_id . '" href="#v1" data-control-id="1"><div id="v1"><div class="wp-video video-control-btn"><video id="video-1" data-is-play="false"><source src="'.$firstVideo[0].'"></video><br/><span class="icon-play video-control-btn" data-control-id="1"></span></div></div></a>
	<a style="width: 750px;" class="wp-video video-control-btn fancybox" href="#v1"><video><source src="'.$firstVideo[0].'"></video><span class="icon-play"></span></a>
	';

	if($firstVideo) $result .= '<a style="width: 750px;display: none;" class="fancybox" rel="gallery-' . $post_id . '" href="#v2" data-control-id="2"><div id="v2"><div class="wp-video video-control-btn"><video id="video-2" data-is-play="false"><source src="'.$secondVideo[0].'"></video><br/><span class="icon-play video-control-btn" data-control-id="2"></span></div></div></a>
	<a style="width: 750px;" class="wp-video video-control-btn fancybox" href="#v2"><video><source src="'.$secondVideo[0].'"></video><span class="icon-play"></span></a>';
	$result .= '</div>';

	return $result;
}
add_shortcode( 'user_videos', 'dl_display_user_videos' );

function dl_display_log_user_video(){
	$result = '';
	$post_id = do_shortcode('[wpv-post-id]');
	$firstVideo = get_post_meta($post_id, 'wpcf-video_1');
	$featuredImgUrl = do_shortcode('[featured_image]');

	$result .= '<div class="videos">';
	if($firstVideo) {
		if ($firstVideo) $result .= '<a style="width: 750px;display: none;" class="fancybox" rel="gallery-' . $post_id . '" href="#v1" data-control-id="1"><div id="v1"><div class="wp-video video-control-btn"><video id="video-1" data-is-play="false"><source src="' . $firstVideo[0] . '"></video><br/><span class="icon-play video-control-btn" data-control-id="1"></span></div></div></a>
						<a style="width: 750px;" class="wp-video video-control-btn fancybox" href="#v1"><video><source src="' . $firstVideo[0] . '"></video><span class="icon-play"></span></a>
						';
	}else{
		$result .= '<a class="fancybox" rel="gallery-' . $post_id . '" href="'.$featuredImgUrl.'"><img src="'.$featuredImgUrl.'" /></a>';
	}
	$result .= '</div>';

	return $result;
}
add_shortcode( 'log_user_video', 'dl_display_log_user_video' );


// add_filter( 'login_redirect', create_function( '$url,$query,$user', 'return home_url();' ), 10, 3 );


// Add mov support
add_filter( 'toolset_valid_video_extentions', 'add_extension_func', 99);
function add_extension_func( $valid_extensions ) {
    $valid_extensions[] = 'mov';
    return $valid_extensions;
}



// Get accommodation profile link (temp)

function dl_get_acc_link() {
	$link = do_shortcode('[types field="accommodation-link"][/types]');
	if (!empty($link)) {
		$link = explode("/", $link);
		$link = $link[count($link)-2];
		return $link;
	}
	return '';
}	
add_shortcode( 'acc_profile', 'dl_get_acc_link' ); 

// Get restaurant profile link (temp)

function dl_get_rest_link() {
	$link = do_shortcode('[types field="restaurant-link"][/types]');
	if (!empty($link)) {
		$link = explode("/", $link);
		$link = $link[count($link)-2];
		return $link;
	}
	return '';
}	
add_shortcode( 'rest_profile', 'dl_get_rest_link' ); 

// Get bar profile link (temp)

function dl_get_bar_link() {
	$link = do_shortcode('[types field="bar-link"][/types]');
	if (!empty($link)) {
		$link = explode("/", $link);
		$link = $link[count($link)-2];
		return $link;
	}
	return '';
}	
add_shortcode( 'bar_profile', 'dl_get_bar_link' ); 

// Get things to do profile link (temp)

function dl_get_things_link() {
	$link = do_shortcode('[types field="things-to-do-link"][/types]');
	if (!empty($link)) {
		$link = explode("/", $link);
		$link = $link[count($link)-2];
		return $link;
	}
	return '';
}	
add_shortcode( 'things_profile', 'dl_get_things_link' ); 

// Get things to do profile link (temp)

function dl_get_bp_avatar() {
	global $wpdb;
	$user_id = get_the_author_meta('ID');
	$avatar_url = bp_core_fetch_avatar ( 
	    array(  'item_id' => $user_id, // id of user for desired avatar
	            'type'    => 'full',
	            'html'   => FALSE     // FALSE = return url, TRUE (default) = return img html
	    ) 
	);
	return '<img src="' . $avatar_url . '">';
}	
add_shortcode( 'bp_avatar', 'dl_get_bp_avatar' ); 

/*--------------------------------------------------------
HISTORY LIST FOR THE POST
---------------------------------------------------------*/

function dl_display_post_history() {
	global $wpdb;
	$post_id = do_shortcode('[wpv-post-id]');
	$city = get_post_meta( $post_id, 'wpcf-location-city', true); 
	$country = get_post_meta( $post_id, 'wpcf-location-country', true); 
	
	// get date
	$month = get_post_meta( $post_id, 'wpcf-month', true); 
	$year = get_post_meta( $post_id, 'wpcf-year', true); 
	$dateObj   = DateTime::createFromFormat('!m', $month);
	$month = $dateObj->format('F'); 

	$history_cats = array('shopping', 'restaurants', 'accommodations', 'bars-clubs', 'sightseeings', 'fun-things-to-do',
		'cafes');

	$output = '<div class="history">';
	
	foreach ($history_cats as $cat) {

		$selection = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'postmeta WHERE post_id = ' . $post_id  . ' AND meta_key = "' . $cat . '"', ARRAY_N );		

		if ($selection[0][0] != '""') {
			$selection = json_decode($selection[0][0]);
			$output .= '<div class="history-section ' . $cat .  '"><h2 class="aqua"><span class="ico ico-' . $cat . '"></span>' . ucfirst($cat) . '</h2><ul>';

			foreach ($selection as $business) {
				$username = explode('/', $business->link);
				$username = $username[count($username)-2];
				$user = get_user_by('login', $username);			
				$photos = get_user_meta( $user->ID, 'photos', true ); 
				if (!empty($photos)) {
					$photos = explode("{", $photos);	
					$photos = explode("}", $photos[1]);
					$photos = explode(';', $photos[0]);
					foreach ($photos as $key => $value) {
						if ($key % 2 == 0)
							unset($photos[$key]);
						else {
							$photos[$key] = substr($value, 2);
						}
					}
					$photos = array_values($photos);
					$photo_id = $photos[0];
					$photo_url = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'postmeta WHERE post_id = ' . $photo_id  . ' AND meta_key = "_wp_attached_file"', ARRAY_N );
					$photo_url = '/wp-content/uploads/' . $photo_url[0][0];
				} else {
					$photo_url = 'http://placehold.it/85x65';
				}
				$output .= '<li class="item"><div class="item-title"><span>' . $business->name . '</span></div><div class="description"><a href="/business-profile/?user=' . $username . '"><div class="place_image" style="background-image: url(' . $photo_url .  ');"></div></a><div class="location">' . $business->address . '</span></div><div class="date"><span>' . $month . ' 12, ' . $year . '</span></div></div></li>';
			}
			$output .= '</ul></div>';
		}					
	}
	$output .= '</div>';
	return $output;
}

add_shortcode( 'post_history', 'dl_display_post_history' ); 
?>
       
          