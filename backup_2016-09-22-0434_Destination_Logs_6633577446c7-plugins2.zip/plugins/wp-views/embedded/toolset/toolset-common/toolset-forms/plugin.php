<?php
/**
 * @package Toolset
 * @version 0.1
 */
/*
Plugin Name: Toolset forms
Plugin URI: http://wp-types.com/toolset-forms/?utm_source=typesplugin&utm_campaign=types&utm_medium=plugins-listing&utm_term=Visit plugin site
Description: Form factory
Author: OTS Toolset team
Version: 0.1
Author URI: http://wp-types.com/?utm_source=typesplugin&utm_campaign=types&utm_medium=plugins-listing&utm_term=OTS Toolset team
*/
require_once 'bootstrap.php';
//include 'test.php';