	<?php wp_nonce_field( 'wsi_save_settings', 'wsi_nonce') ?>
	<p class="submit">
		<input name="Submit" type="submit" class="button-primary" value="<?php _e( 'Save Changes', 'wsi');?>" />
	</p>

</form>
</div><!--wsi settings-->