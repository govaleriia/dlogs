<?php
/**
 * Free version sharing collector template
 * @link       http://wp.timersys.com/wordpress-social-invitations/
 * @since      2.0.3
 *
 * @package    Wsi
 * @subpackage Wsi/templates/popup/collector
 */
?>
<h2><?php echo sprintf(__("Invite your %s friends!", 'wsi'), $provider);?></h2>
