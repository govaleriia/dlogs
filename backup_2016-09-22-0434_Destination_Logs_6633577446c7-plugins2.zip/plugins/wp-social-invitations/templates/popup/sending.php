<div id="wsi_loading">
<table width="100%" border="0">
  <tr>
    <td align="center" height="40px"><br /><br /><?php _e( 'Sending Invitations, please wait...', 'wsi');  ?></td>
  </tr> 
  <tr>
    <td align="center" height="80px" valign="middle"><img src="<?php echo WSI_PLUGIN_URL; ?>public/assets/img/loading2.gif" /></td>
  </tr> 
</table> 
</div>