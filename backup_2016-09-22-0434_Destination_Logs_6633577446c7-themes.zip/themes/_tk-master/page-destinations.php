<?php
/**
 * Template name: Destinations
 *
 * @package _tk
 */

get_header(); ?>

<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-xs-12">
                <div class="search-bar left-icon-i">
                    <input type="text" placeholder="Text" class="search-control">
                    <a class="search-btn" href="#"></a>
                </div>
            </div>
            <div class="col-sm-12 col-xs-12">
                <h2>Text</h2>
                <div class="search-view view-type-4">
                    <div class="item">
                        <div class="image-container">
                            <img src="http://placehold.it/780x320">
                        </div>
                        <div class="title">
                            <a href="#">Text</a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="image-container">
                            <img src="http://placehold.it/780x320">
                        </div>
                        <div class="title">
                            <a href="#">Text</a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="image-container">
                            <img src="http://placehold.it/780x320">
                        </div>
                        <div class="title">
                            <a href="#">Text</a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="image-container">
                            <img src="http://placehold.it/780x320">
                        </div>
                        <div class="title">
                            <a href="#">Text</a>
                        </div>
                    </div>
                    <div class="item">
                        <div class="image-container">
                            <img src="http://placehold.it/780x320">
                        </div>
                        <div class="title">
                            <a href="#">Text</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>
