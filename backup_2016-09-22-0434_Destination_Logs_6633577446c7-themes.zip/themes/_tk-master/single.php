<?php
/**
 * The Template for displaying all single posts.
 *
 * @package _tk
 */

get_header(); ?>

<?php get_sidebar(); ?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/theme_styles_new.css'; ?>">
<div id="content" class="content">

	<?php while ( have_posts() ) : the_post(); ?>

		<?php get_template_part( 'content', 'single' ); ?>

	<?php endwhile; // end of the loop. ?>

</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>