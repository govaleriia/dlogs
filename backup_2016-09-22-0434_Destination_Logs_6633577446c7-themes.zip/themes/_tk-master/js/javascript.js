(jQuery)(function($){
	
	$('.wp-video.video-control-btn.fancybox video').on('loadedmetadata', function() {
			var $width, $height,
				$vidwidth = this.videoWidth, 
				$vidheight = this.videoHeight, 
				$aspectRatio = $vidwidth / $vidheight;
				
				
			(adjSize = function() { 
							
				$width = $('.wp-video.video-control-btn.fancybox').width();
				$height = $('.wp-video.video-control-btn.fancybox').height();
							
				$boxRatio = $width / $height; 
							
				$adjRatio = $aspectRatio / $boxRatio;
							
				
				
							
				if($boxRatio < $aspectRatio) { 
					
					$vid = $('.wp-video.video-control-btn.fancybox video').css({'width' : $width*$adjRatio+'px'}); 
				} else {
					
					$vid = $('.wp-video.video-control-btn.fancybox video').css({'width' : $width+'px'});
				}
								 
			})();
						
			//on window resize.
			$(window).resize(adjSize);
						
		});
	
});