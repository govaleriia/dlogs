jQuery(document).ready(function($){

    var fancyBoxOptions = {
        scrollOutside: false,
        openEffect: 'elastic',
        closeEffect: 'elastic',
        nextEffect: 'elastic',
        prevEffect: 'elastic',
        padding: 0,
        width: 100,
        height: 100,
        fitToView: true,
        wrapCSS: 'styled-wrap'
    };

    if(checkForDevice('any')){
        fancyBoxOptions.arrows = false;
        fancyBoxOptions.afterShow = function(e){
            $('.fancybox-wrap').swipe({
                swipeLeft: function(){
                    $.fancybox.next();
                },
                swipeRight: function(){
                    $.fancybox.prev();
                }
            });
        };
    }

    // Album gallery
    var fancybox = $('.fancybox').fancybox(fancyBoxOptions);

    // init modal overlay
    $('.modal').prepend('<div class="modal-overlay"></div>');

    $('.video-control-btn').on('click', function(e){
        e.preventDefault();
        var id = $(this).data('controlId');
        var video = document.getElementById('video-' + id);
        var isPlay = video.dataset.isPlay;

        if(isPlay === "false"){
            video.play();
        } else {
            video.pause();
        }

        video.onpause = function() {
            video.controls = false;
            video.dataset.isPlay = false;
            video.nextSibling.style.display = "block";
        };

        video.onplay = function(){
            video.controls = true;
            video.dataset.isPlay = true;
            video.nextSibling.style.display = "none";
        }
    });

});

function checkForDevice(device){
    switch(device){
        case 'Android':
            return navigator.userAgent.match(/Android/i);
            break;

        case 'BlackBerry':
            return navigator.userAgent.match(/BlackBerry/i);
            break;

        case 'iOS':
            return navigator.userAgent.match(/iPhone|iPad|iPod/i);
            break;

        case 'Opera':
            return navigator.userAgent.match(/Opera Mini/i);
            break;

        case 'Windows':
            return navigator.userAgent.match(/IEMobile/i);
            break;

        case 'any':
            return (checkForDevice('Android') || checkForDevice('BlackBerry') || checkForDevice('iOS') || checkForDevice('Opera') || checkForDevice('Windows'));
            break;

        default:
            return false;
            break;
    }

}