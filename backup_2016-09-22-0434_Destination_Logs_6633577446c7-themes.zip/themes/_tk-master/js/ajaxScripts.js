jQuery(document).ready(function($){
    var lazyLoadPage = 1;
    var visibleTabName = 'new_logs';

    get_Ajax_data(visibleTabName, lazyLoadPage, false);

    $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
        e.target // newly activated tab
        e.relatedTarget // previous active tab

        lazyLoadPage = 1;
        visibleTabName = e.target.dataset.tabName;

        get_Ajax_data(visibleTabName, lazyLoadPage, false);
    }).on('hide.bs.tab', function(){
        $('.ajax-response').html('');
    });

    $(window).scroll(function(){
        if($(window).scrollTop() == $(document).height() - $(window).height()){
            get_Ajax_data(visibleTabName, ++lazyLoadPage, true);
        }
    });

});

function get_Ajax_data(actionIndex, page, isSameTab){
    jQuery.ajax({
        cache: false,
        timeout: 8000,
        url: window.wp_data.ajax_url,
        type: "POST",
        data: ({ action: 'get_' + actionIndex + '_data', page: page, itemsPerPage: 6 }),

        beforeSend: function() {
            jQuery( '.ajax-preloader' ).addClass('visible');
        },

        success: function( data, textStatus, jqXHR ){
            var $ajax_response = jQuery( data );

            jQuery( '.ajax-preloader' ).removeClass('visible');

            if(isSameTab) jQuery( '.ajax-response' ).append( $ajax_response );
            else jQuery( '.ajax-response' ).html( $ajax_response );
        },

        error: function( jqXHR, textStatus, errorThrown ){
            console.log( 'The following error occured: ' + textStatus, errorThrown );
        },

        complete: function( jqXHR, textStatus ){
        }
    });
}