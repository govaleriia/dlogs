<?php

/**
 * Template name: Friends
 *
 * @package _tk
 */



get_header(); ?>
<?php get_sidebar(); ?>
<div id="content" class="content">

<?php 

    if (is_user_logged_in()) {    
        $friend_ids = friends_get_friend_user_ids( bp_loggedin_user_id() );   
        foreach ($friend_ids as $key => $value) {
        	$user = get_user_by('ID', $username);
        	echo '<div class="friend">';
        	echo $user->first_name;
        	echo '</div>';
        }

    }
        

    ?> 
</div>
<?php get_footer(); ?>
