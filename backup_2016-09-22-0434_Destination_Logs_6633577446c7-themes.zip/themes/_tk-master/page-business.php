<?php
/**
 * Template name: Business
 *
 * @package _tk
 */

get_header(); ?>

<?php get_sidebar(); ?>

<?php 
	global $wpdb;
	$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$parts = parse_url($url);
	parse_str($parts['query'], $query);
	$username = $query['user'];

	$user = get_user_by('login', $username);

	$country = get_user_meta( $user->ID, 'country', true ); 
	$city = get_user_meta( $user->ID, 'city', true ); 
	
	$photos = get_user_meta( $user->ID, 'photos', true ); 
	if (!empty($photos)) {
		$photos = explode("{", $photos);	
		$photos = explode("}", $photos[1]);
		$photos = explode(';', $photos[0]);
		foreach ($photos as $key => $value) {
			if ($key % 2 == 0)
				unset($photos[$key]);
			else {
				$photos[$key] = substr($value, 2);
			}
		}
		$photos = array_values($photos);

		$urls = array();
		foreach ($photos as $key => $value) {
			$urls[$key] = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'postmeta WHERE post_id = ' . $photos[$key]  . ' AND meta_key = "_wp_attached_file"', ARRAY_N );
		}
	}
	

	$logo_id = get_user_meta( $user->ID, 'logo', true );
	$logo_url = ""; 
	if (!empty($logo_id)) {
		$logo_url = $wpdb->get_results( 'SELECT meta_value FROM '. $wpdb->prefix . 'postmeta WHERE post_id = ' . $logo_id  . ' AND meta_key = "_wp_attached_file"', ARRAY_N );
	} 

	// Get category
	$categories = $wpdb->get_results( 'SELECT term_taxonomy_id FROM '. $wpdb->prefix . 'term_relationships WHERE object_id = ' . $user->ID, ARRAY_N );
	$cat_name = array();
	foreach ($categories as $category) {
		if ($category > 17) {
			foreach ($category as $key => $value) {
				$cat_name[$key] = $wpdb->get_results( 'SELECT name FROM '. $wpdb->prefix . 'terms WHERE term_id = ' . $value, ARRAY_N );	
			}
		}					
	}

	// Make a string from categories
	$cat_print = '';
	foreach ($cat_name as $key => $value) {
		$cat_print .= $value[0][0] . ', ';
	}
	$cat_print = substr($cat_print, 0, -2);



	



?>
<div id="content" class="content">

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="bizprofile">
		<div class="biz-wrap bdaqua">
			<table class="item-header">
			  <tr>
			  	<?php if (!empty($logo_url)) : ?>
			  		<td class="avatar"><img src="/wp-content/uploads/<?php echo $logo_url[0][0]; ?>"></td>
			  	<?php endif; ?>
			    
			    <td class="captions">
			      <p class="name semi"><?php echo $user->display_name; ?> 
			      <span style="font-size: 14px;color: #777;"><?php echo $cat_print; ?><span></p>
			      <p class="location bold"><?php echo $city; ?> &bull; <?php echo $country; ?></p>
			    </td>
			    <td class="actions">
			      	<table>
			    		<tr>
			    			<td></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/shared.png" class="icon"></td>
			    		</tr>
			    		<tr>
			    			<td><span class="love_counter">23987</span></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/love.png" class="icon"></td>
			    		</tr>
			    	</table>      	
			    </td>
			  </tr>
			</table>
			<div class="gallery clearfix">
				<div class="featured">

					<?php 
						
					?>
					<div class="image" style="background-image: url('/wp-content/uploads/<?php echo $urls[0][0][0]; ?>');"></div>
				</div>
				<div class="thumbs clearfix">
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/uploads/<?php echo $urls[1][0][0]; ?>');"></div>
					</div>
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/uploads/<?php echo $urls[2][0][0]; ?>');"></div>
					</div>
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/uploads/<?php echo $urls[3][0][0]; ?>');"></div>
					</div>
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/uploads/<?php echo $urls[4][0][0]; ?>');"></div>
					</div>
				</div>
			</div>

			 <div class="faces bgaqua">
			 	<h3>Kiara and 23456 other users like this</h3>
                <ul class="clearfix">
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/01.jpg" class="face">
                        <span>Claire</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/02.jpg" class="face">
                        <span>Tisha</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/03.jpg" class="face">
                        <span>Rob</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/04.jpg" class="face">
                        <span>Alina</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/05.jpg" class="face">
                        <span>Isabelle</span>
                    </li>
                    <li class="hide_on_mobile">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/06.jpg" class="face">
                        <span>Alan</span>
                    </li>
                    <li class="hide_on_mobile">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/07.jpg" class="face">
                        <span>Bea</span>
                    </li>
                    <li class="hide_on_tablet">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/08.jpg" class="face">
                        <span>John</span>
                    </li>
                    <li class="hide_on_tablet">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/09.jpg" class="face">
                        <span>Marry</span>
                    </li>
                </ul>
            </div>  

            <div class="action flexlist">
            	<div class="book_wrap">
            		<div class="bdfiesta" style="border: 2px solid;">
	            		<h4 class="bgfiesta">Book</h4>
	            		<ul class="flexlist">
	            			<li><div class="logo_wrap bdfiesta"><img src="/wp-content/themes/_tk-master/img/travelBizLogos/expedia.png"></div></li>
	            			<li><div class="logo_wrap bdfiesta"><img src="/wp-content/themes/_tk-master/img/travelBizLogos/trivago.png"></div></li>
	            			<li><div class="logo_wrap bdfiesta"><img src="/wp-content/themes/_tk-master/img/travelBizLogos/tripAdvisor.png"></div></li>
	            			<li><div class="logo_wrap bdfiesta"><img src="/wp-content/themes/_tk-master/img/travelBizLogos/bookingcom.png"></div></li>
	            		</ul>
	            	</div>
            	</div>
            </div>

            <div class="about"><span class="ico ico-about"></span>About <span class="upper">W Hotel</span></div>

		</div>
	</div>
	<div class="biz_posts">
		<p class="posts_title aqua">Latest posts:</p>
		<div class="wrap clearfix">
			<div class="deal-wrap">
					<div class="deal">					
						<div class="deal-header-wrap">
							<table class="deal-header">
							  	<tr>
								    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/whotel.png"></td>
								    <td class="captions">
							      		<p class="name">W Hotel</p>
							      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
							    	</td>
							  	</tr>
							</table>
						</div>				  	
						<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/whotelPromo.jpg');"></div>
						<div class="text">
							<h4 class="aqua">WEEKEND FOR 2</h4>
							<p>Come to the award winning W Hotel and enjoy a weekend far away from the husle.
							2 Nights / 1 Dinner for 2 / Tickets to 1 Summer Event.
							Valid from 15 july to 15 August.</p>
							<a href="" class="readmore">Read more</a>
						</div>
					</div>
				</div>

				<div class="deal-wrap">
					<div class="deal">					
						<div class="deal-header-wrap">
							<table class="deal-header">
							  	<tr>
								    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/aquaSpa.png"></td>
								    <td class="captions">
							      		<p class="name">Aqua Spa Therapy</p>
							      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
							    	</td>
							  	</tr>
							</table>
						</div>				  	
						<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/spa.png');"></div>
						<div class="text">
							<h4 class="aqua">Summer Spa Promotion</h4>
							<p>Enjoy our award winning Plenitude treatment promoting relaxation and renewal. 2 hours treatment with essential oils from Bali. 
							Reserved for 18 and older.</p>
							<a href="" class="readmore">Read more</a>
						</div>
					</div>
				</div>

				<div class="deal-wrap">
					<div class="deal">					
						<div class="deal-header-wrap">
							<table class="deal-header">
							  	<tr>
								    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/rafting.png"></td>
								    <td class="captions">
							      		<p class="name">KRAKATOA RAFTING</p>
							      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
							    	</td>
							  	</tr>
							</table>
						</div>				  	
						<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/rafting.jpg');"></div>
						<div class="text">
							<h4 class="aqua">UNFORGETTABLE RAFTING EXPERIENCE</h4>
							<p>Join our team of expert rafting guides for an unforgetable journey of four hours down the river Krakatoa. Starts at 8am / Food & Beverages provided.</p>
							<a href="" class="readmore">Read more</a>
						</div>
					</div>
				</div>

				<div class="deal-wrap">
					<div class="deal">					
						<div class="deal-header-wrap">
							<table class="deal-header">
							  	<tr>
								    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/whotel.png"></td>
								    <td class="captions">
							      		<p class="name">Aqua Spa Therapy</p>
							      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
							    	</td>
							  	</tr>
							</table>
						</div>				  	
						<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/whotelPromo.jpg');"></div>
						<div class="text">
							<h4 class="aqua">WEEKEND FOR 2</h4>
							<p>Come to the award winning W Hotel and enjoy a weekend far away from the husle.
							2 Nights / 1 Dinner for 2 / Tickets to 1 Summer Event.
							Valid from 15 july to 15 August.</p>
							<a href="" class="readmore">Read more</a>
						</div>
					</div>				
				</div>			
			</div>
		</div>

		<!-- <div class="body bdaqua">
			<table class="item-header">
				  <tr>
				    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/whotel.png"></td>
				    <td class="captions">
				      <p class="name semi aqua">W Hotel</p>
				      <p class="location bold">Bali &bull; Indonesia</p>
				    </td>
				    <td class="actions">
				      	<table>
			    		<tr>
			    			<td></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/shared.png" class="icon share"></td>
			    		</tr>
			    		<tr>
			    			<td><span class="love_counter">23987</span></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/love.png" class="icon love"></td>
			    		</tr>
			    	</table>      	
				    </td>
				  </tr>
				</table>
			<img src="/wp-content/themes/_tk-master/img/temp/whotelPromo.jpg" alt="" class="promo_img">
			<div class="offer">
				<table>
					<tr>
						<td rowspan="3" class="color bgfiesta" style=""></td>
						<td class="title aqua">Weekend for 2</td>
						<td rowspan="3" class="action">
							<a href="#" title="" class="price precise"><span class="value">480$</span></a>
							<a href="#" title="" class="book">Book</a>
						</td>
					</tr>
					<tr>
						<td class="desc">
							Come to the award winning W Hotel and enjoy a weekend far away from the husle.<br>
							2 Nights / 1 Dinner for 2 / Tickets to 1 Summer Event.<br>
							Valid from 15 july to 15 August.    	
						</td>
					</tr>
					<tr>
						<td class="more">
							<a href="">Read more</a> 
						</td>
					</tr>
				</table>
				<a href="#" class="boost bgaqua">Boost post</a>
			</div>
		</div>

		<div class="body bdaqua">
			<table class="item-header">
				  <tr>
				    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/aquaSpa.png"></td>
				    <td class="captions">
				      <p class="name semi aqua">Aqua Spa Therapy</p>
				      <p class="location bold">Bali &bull; Indonesia</p>
				    </td>
				    <td class="actions">
				      	<table>
			    		<tr>
			    			<td></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/shared.png" class="icon share"></td>
			    		</tr>
			    		<tr>
			    			<td><span class="love_counter">23987</span></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/love.png" class="icon love"></td>
			    		</tr>
			    	</table>      	
				    </td>
				  </tr>
				</table>
			<img src="/wp-content/themes/_tk-master/img/temp/spa.png" alt="" class="promo_img">
			<div class="offer">
				<table>
					<tr>
						<td rowspan="3" class="color" style="background-color: #fff;"></td>
						<td class="title aqua">Summer Spa Promotion</td>
						<td rowspan="3" class="action">
							<a href="#" title="" class="price"><span class="note">Starts at</span> <span class="value">120$</span></a>
							<a href="#" title="" class="book">Book</a>
						</td>
					</tr>
					<tr>
						<td class="desc">
							Enjoy our award winning Plenitude treatment promoting relaxation and renewal. 2 hours treatment with essential oils from Bali. <br>
							Reserved for 18 and older.	
						</td>
					</tr>
					<tr>
						<td class="more">
							<a href="">Read more</a> 
						</td>
					</tr>
				</table>
				<a href="#" class="boost bgaqua">Boost post</a>
			</div>
		</div>

		<div class="body bdaqua">
			<table class="item-header">
				  <tr>
				    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/rafting.png"></td>
				    <td class="captions">
				      <p class="name semi aqua">Krakatoa Rafting</p>
				      <p class="location bold">Bali &bull; Indonesia</p>
				    </td>
				    <td class="actions">
				      	<table>
			    		<tr>
			    			<td></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/shared.png" class="icon share"></td>
			    		</tr>
			    		<tr>
			    			<td><span class="love_counter">23987</span></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/love.png" class="icon love"></td>
			    		</tr>
			    	</table>      	
				    </td>
				  </tr>
				</table>
			<img src="/wp-content/themes/_tk-master/img/temp/rafting.jpg" alt="" class="promo_img">
			<div class="offer">
				<table>
					<tr>
						<td rowspan="3" class="color bgaqua" style=""></td>
						<td class="title aqua">Unforgettable rafting experience</td>
						<td rowspan="3" class="action">
							<a href="#" title="" class="price precise"><span class="value">60$/Pax</span></a>
							<a href="#" title="" class="book">Book</a>
						</td>
					</tr>
					<tr>
						<td class="desc">
							Join our team of expert rafting guides for an unforgetable journey of four hours down the river Krakatoa. <br>
							Starts at 8am / Food & Beverages provided.
						</td>
					</tr>
					<tr>
						<td class="more">
							<a href="">Read more</a> 
						</td>
					</tr>
				</table>
				<a href="#" class="boost bgaqua">Boost post</a>
			</div> -->
		</div>
	</div>
</article><!-- #post-## -->


</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
