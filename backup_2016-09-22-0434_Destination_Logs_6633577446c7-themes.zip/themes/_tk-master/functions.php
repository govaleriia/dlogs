<?php
/**
 * _tk functions and definitions
 *
 * @package _tk
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) )
	$content_width = 750; /* pixels */

if ( ! function_exists( '_tk_setup' ) ) :
/**
 * Set up theme defaults and register support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function _tk_setup() {
	global $cap, $content_width;

	// Add html5 behavior for some theme elements
	add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

    // This theme styles the visual editor with editor-style.css to match the theme style.
	add_editor_style();

	/**
	 * Add default posts and comments RSS feed links to head
	*/
	add_theme_support( 'automatic-feed-links' );

	/**
	 * Enable support for Post Thumbnails on posts and pages
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	*/
	add_theme_support( 'post-thumbnails' );

	/**
	 * Enable support for Post Formats
	*/
	add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link' ) );
	
	/**
	 * Make theme available for translation
	 * Translations can be filed in the /languages/ directory
	 * If you're building a theme based on _tk, use a find and replace
	 * to change '_tk' to the name of your theme in all the template files
	*/
	load_theme_textdomain( '_tk', get_template_directory() . '/languages' );

}
endif; // _tk_setup
add_action( 'after_setup_theme', '_tk_setup' );


/**
 * Enqueue scripts and styles
 */
function _tk_scripts() {

	// load bootstrap css
	wp_enqueue_style( '_tk-bootstrap', get_template_directory_uri() . '/includes/resources/bootstrap/css/bootstrap.min.css' );


	// load _tk styles
	wp_enqueue_style( '_tk-style', get_stylesheet_uri() );
	wp_enqueue_style( '_temp-styles', get_template_directory_uri() . '/includes/css/styles-temp.css' );
	wp_enqueue_style( '_temp-styles', get_template_directory_uri() . 'styles_feed_fp.css' );

	// load bootstrap js
	wp_enqueue_script('_tk-bootstrapjs', get_template_directory_uri().'/includes/resources/bootstrap/js/bootstrap.min.js', array('jquery') );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}


	// gmaps
	if (is_page_template('page-map.php') || is_page_template('page-profile-own.php') || is_page_template('page-profile.php') || is_page_template('page-home-nd.php') || is_single()) {
		wp_enqueue_style('_tk-gmaps-css', get_stylesheet_directory_uri() . '/includes/css/gmaps.css', array(), '05082016');
		wp_enqueue_script('_tk-gmaps-marker-cluster-js', get_stylesheet_directory_uri() . '/includes/js/gmaps-marker-cluster.js', array('jquery'), '05082016', true);
		wp_enqueue_script('_tk-gmaps-custom-controls-js-my', get_stylesheet_directory_uri() . '/includes/js/gmaps-custom-controls.js', array('jquery'), '05082016', true);
		wp_enqueue_script('_tk-gmaps-js-my', get_stylesheet_directory_uri() . '/includes/js/gmaps.js', array('jquery'), '05082016', true);
		wp_enqueue_script('_tk-gmaps-js', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBAR3MCnnHCYi7hH34-2QImLbiwQQS94dY&language=en&callback=initMap', array(), '05082016', true);
		wp_enqueue_script('_tk-gmaps-custom-marker-js-my', get_stylesheet_directory_uri() . '/includes/js/gmaps-custom-marker.js', array('jquery'), '05082016', true);
	}

	if (is_home() || is_singular()) {
		// Fancybox including
		wp_enqueue_style( 'fancyboxStyles', get_template_directory_uri() . '/includes/resources/fancybox/jquery.fancybox.css' );
		wp_enqueue_script( 'fancyboxScripts', get_template_directory_uri() . '/includes/resources/fancybox/jquery.fancybox.pack.js' );
        // Ajax scripts
		wp_enqueue_script( '_ajaxScripts', get_template_directory_uri() . '/js/ajaxScripts.js', array('jquery') );
	}


	// Core scripts
	wp_enqueue_script( 'coreScripts', get_template_directory_uri() . '/js/core.js');
	
}
add_action( 'wp_enqueue_scripts', '_tk_scripts' );

/*--------------------------------------------------------
CUSTOMIZE LOGIN SCREEN
---------------------------------------------------------*/


function my_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
    return 'Destination Logs';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );

// add a new logo to the login page
function custom_login_logo() { ?>
    <style type="text/css">
        .login #login h1 a {background-image: url( '/wp-content/themes/_tk-master/img/logo.png' );margin-bottom: 30px !important;}
        div#login h1, .login #login_error, .login .message, .login form, p#nav,
        .login #backtoblog, .login #nav {background: transparent;color: #fff;}
        .login h1 a {height: 90px !important;width: 300px !important;background-size: 64% !important;background-position: 50% 100% !important;margin-bottom: 0 !important;}
        .login form {background-color: transparent;box-shadow: none;padding: 0px 20px 30px;margin-top: 0 !important;}
        .login #login_error, .login .message {background-color: transparent;box-shadow: none;border:0;padding: 40px 20px 20px;}
        body.login {background-color: #019AFF;}
        .login #backtoblog a, .login #nav a, .login h1 a {color: #fff;}
        p#nav {margin: 0 !important;}
        .login #backtoblog, .login #nav {padding: 6px !important;margin: 0 !important;text-align: center;}
        .login #backtoblog {padding-bottom: 24px !important;}
        .wp-core-ui .button-group.button-large .button, .wp-core-ui .button.button-large, 
        .wp-core-ui .button-primary {background: #0D679A !important; border: 0;}
        p.message, div#login_error {border: 0 !important;padding: 32px 24px 0!important;}
        p#nav a:first-child {display: none;}
        a.wp-social-login-provider.wp-social-login-provider-facebook {
		    background-color: #3B5998;
		    display: block;
		    padding: 10px;
		    text-align: center;
		    color: #fff;
		    text-transform: uppercase;
		    font-weight: bold;
		}
		.wp-social-login-provider-list {
		    padding: 0 !important;
		    margin-bottom: 30px !important;
		}
		.wp-social-login-connect-with {
		    color: #333;
		    padding-bottom: 4px;
		}
		.wp-core-ui .button-group.button-large .button, .wp-core-ui .button.button-large, .wp-core-ui .button-primary {
		    background: #FF7674 !important;
		}
		.wp-core-ui .button-primary {text-shadow: none !important;box-shadow: none !important;}
		.wp-social-login-connect-with {margin-bottom: 8px !important;}
		p#nav, p#backtoblog {display: none;}
		.login #login h1 a:focus {box-shadow: none;}
		#login {padding-top: 6% !important;}
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'custom_login_logo' );

/**
 * Handlers for the ajax transport search
 */
require get_template_directory() . '/includes/ajax/transport-search.php';

/**
 * Handlers for the ajax map information
 */
require get_template_directory() . '/includes/ajax/gmap-about-me.php';
require get_template_directory() . '/includes/ajax/gmap-destinations.php';
require get_template_directory() . '/includes/ajax/gmap-destinations-years.php';
require get_template_directory() . '/includes/ajax/gmap-bucket-list.php';

/**
 * Adds custom classes to the array of body classes.
 */
function _tk_body_classes( $classes ) {
	// Adds a class of group-blog to blogs with more than 1 published author
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	return $classes;
}
add_filter( 'body_class', '_tk_body_classes' );



/** Register Ajax scripts */

add_action('wp_ajax_get_new_logs_data', 'get_ajax_new_logs_data');
add_action('wp_ajax_nopriv_get_new_logs_data', 'get_ajax_new_logs_data');
function get_ajax_new_logs_data() {

    $response = '';
	$i = 0;
    //$response .= do_shortcode('[wpv-view name="feed-latest"]');

    $args = array(
        'post_type' => 'log',
        'posts_per_page' => $_POST['itemsPerPage'],
        'paged' => $_POST['page']
    );

    $query = new WP_Query( $args );
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
        	if($i != 0) {
				$query->the_post();
				$response .= do_shortcode('[wpv-post-body view_template="loop-item-in-feed-latest"]');
			}
			$i++;
        }
    }

    echo $response;
    wp_reset_postdata();
    wp_die();
}
add_action('wp_ajax_get_friends_data', 'get_ajax_friends_data');
add_action('wp_ajax_nopriv_get_friends_data', 'get_ajax_friends_data');
function get_ajax_friends_data() {

    if (is_user_logged_in()) {
        $friend_ids = friends_get_friend_user_ids( bp_loggedin_user_id() );

        if ( ! empty( $friend_ids )) {
            $args = array(
                    'post_type' => 'log',
                    'author__in' => $friend_ids
            );
            $query = new WP_Query( $args );

            if ( $query->have_posts() ) {
                while ( $query->have_posts() ) {
                    $query->the_post();
                    echo do_shortcode('[wpv-post-body view_template="loop-item-in-feed-latest"]');
                }
            } else {
                echo '<p>You have no friends of they haven\'t published anything yet. :(</p>';
            }
        } else {
            echo '<p>Error :(</p>';
        }
    } else { echo '<p>You need to login to see the posts of your friends.</p>'; }

    wp_die();
}
add_action('wp_ajax_get_favorites_data', 'get_ajax_favorites_data');
add_action('wp_ajax_nopriv_get_favorites_data', 'get_ajax_favorites_data');
function get_ajax_favorites_data() {

    if (is_user_logged_in()) {
        global $wpdb;
        $string = 'SELECT post_id FROM '. $wpdb->prefix . 'ulike WHERE user_id = ' . do_shortcode('[wpv-user field="ID"]') . ' AND status = "like"';
        $liked = $wpdb->get_results( $string, ARRAY_N);
        $liked_ids =  array();
        foreach ($liked as $value) {
            $liked_ids[] = $value[0];
        }
        if (!empty($liked_ids)) {
            $args = array(
                'post_type' => 'log',
                'post__in' => $liked_ids,
                'posts_per_page' => $_POST['itemsPerPage'],
                'paged' => $_POST['page']
            );
            $query = new WP_Query( $args );

            if ( $query->have_posts() ) {
                while ( $query->have_posts() ) {
                    $query->the_post();
                    echo do_shortcode('[wpv-post-body view_template="loop-item-in-feed-latest"]');
                }
            }
            wp_reset_postdata();
        } else {
            echo '<p>You haven\'t liked anything yet.</p>';
        }

    } else {
        echo '<p>You need to login to see your favorite posts.</p>';
    }

    wp_die();
}
