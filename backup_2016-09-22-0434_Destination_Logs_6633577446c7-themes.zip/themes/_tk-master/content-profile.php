<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package _tk
 */
?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/theme_styles_new.css'; ?>">

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="profile">
		<?php 
			$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$parts = parse_url($url);
			parse_str($parts['query'], $query);
			$username = $query['user'];
			// $user_id = $query['user'];
			$user = get_user_by('login', $username);
			$user_id = $user->ID;

			// TODO: only for url /?user=#
			//$user_id = $_GET['user'];
		?>
		<?php 
			$cover = get_user_meta( $user_id, 'wpcf-cover', true); 
			$avatar = get_user_meta( $user_id, 'wpcf-avatar', true); 
			$xfactor = get_user_meta( $user_id, 'wpcf-x-factor-str', true); 
			$from = get_user_meta( $user_id, 'wpcf-user-from-city', true); 
			$lives = get_user_meta( $user_id, 'wpcf-user-lives-city', true); 
			$countries = get_user_meta( $user_id, 'wpcf-countries-travelled', true); 
			$cities = get_user_meta( $user_id, 'wpcf-cities-travelled', true); 
			$points = get_user_meta( $user_id, 'wpcf-points', true); 
			$name = do_shortcode('[wpv-user field="user_firstname" id="' . $user_id . '"]') . ' ' . do_shortcode('[wpv-user field="user_lastname" id="' . $user_id . '"]');
		?>
		<div class="cover guest-view" style="width: 100%;height: 304px;background-image: url(<?php echo $cover; ?>);">
			<?php // echo do_shortcode('[wp_ulike]'); ?>
			<div class="user-profile-info">
				<div class="avatar-big">
					<img src="<?php echo $avatar; ?>">
				</div>
				<div class="user-info">
					<div class="user-name">
						<span><?php echo $name; ?></span>
					</div>
					<div class="user-title">
						<span class="font-bold">Wanderlust</span>
					</div>
					<div class="user-location">
						<span>From <?php echo $from; ?></span>
						<span>Lives in <?php echo $lives; ?></span>
						<span class="status-mobile">Status <b>Wanderlust</b></span>
					</div>
				</div>
			</div>
		</div>
<!--		<img src="http://dl.nexdna.com/wp-content/themes/_tk-master/img/addfriend.png" class="addfriend">
		<img src="http://dl.nexdna.com/wp-content/themes/_tk-master/img/share_cover.png" class="share_cover">-->
		<!--<div class="card">
			<div class="avatar"></div>
			<div class="about">
				<h1 class="name aqua"><?php /*echo $name; */?></h1>
				<p><span class="aqua">X-Factor:</span> <?php /*echo $xfactor; */?></p>
				<p><span class="aqua">Travelled:</span> <strong><?php /*echo $countries; */?></strong> countries, <strong><?php /*echo $cities; */?></strong> cities</p>
				<p><span class="aqua">Karma points:</span> <strong><?php /*echo $points; */?></strong>
				<p><span class="aqua">Lives in:</span> <?php /*echo $lives; */?> &bull; <span class="aqua">From:</span> <?php /*echo $from; */?></p>
			</div>
			<div class="info">
				<div class="love_counter"><span class="ico ico-loved"></span> <span>467</span> </div>
				<div class="stamp"><img src="<?php /*bloginfo('template_directory'); */?>/img/stamp.jpg"></div>
			</div>
		</div>-->
		<div id="map" data-user-id="<?php echo $user_id;?>"></div>
		<div class="tabs-bar styled-tabs">
	        <ul class="nav nav-tabs bglaqua profile-tabs" role="tablist">
	            <li class="active"><a href="#tab-1" aria-controls="tab-1" role="tab" data-toggle="tab"><span>Destinations [
	            	<?php echo count_user_posts( $user_id , "log"  ); ?>
	            ]</span></a></li>
				<!-- <li><a href="#tab-2" aria-controls="tab-2" role="tab" data-toggle="tab"><span class="ico ico-friends"></span><span>My city</span><span class="count">2</span></a></li> -->
	            <!-- <li><a href="#tab-2" aria-controls="tab-2" role="tab" data-toggle="tab">Friends</a></li>
	            <li><a href="#tab-3" aria-controls="tab-3" role="tab" data-toggle="tab">Favorites</a></li>
	            <li><a href="#tab-3" aria-controls="tab-3" role="tab" data-toggle="tab"><span class="ico ico-loupe"></span></a></li> -->
	        </ul>
	    </div>

		<div class="tab-content">
	        <div role="tabpanel" class="tab-pane active bdaqua" id="tab-1">
				
	        	<div class="two_col_posts clearfix">
			        <?php
			       		$args = array(
		                    'post_type' => 'log',
		                    'author' => $user_id
		                    ); 
		                $query = new WP_Query( $args );

		                if ( $query->have_posts() ) {                           
		                    while ( $query->have_posts() ) {
		                        $query->the_post();
		                        echo do_shortcode('[wpv-post-body view_template="loop-item-in-feed-latest"]');
		                    }
		                }
		                wp_reset_postdata();
		            ?>
            	</div>

	        </div>
	        <div role="tabpanel" class="tab-pane bdaqua" id="tab-2"> </div>
	        <div role="tabpanel" class="tab-pane bdaqua" id="tab-3"> </div>
	        <div role="tabpanel" class="tab-pane bdaqua" id="tab-4"> </div>


        </div>
	</div>
</article><!-- #post-## -->
