<?php
/**
 * The sidebar containing the main widget area
 *
 * @package _tk
 */
?>

<?php if (is_user_logged_in()) : ?>
<div id="sidebar" class="fixed-sidebar">
    <aside>
        <div class="user-section bglblue">
            <div class="avatar-big">
                <a href="/my-profile/"><?php bp_loggedin_user_avatar( 'type=full' ); ?></a>
            </div>
            <div class="username">
                <a href="/my-profile/"><?php echo do_shortcode('[wpv-user field="user_firstname"]'); ?></a>
            </div>
        </div> 
        <div class="sidebar_buttons">
            <ul class="inline-list">
                <li><a class="bgfiesta" href="/add-new/"><span class="ico ico-addnew"></span> New Log</a></li>
                <li><a class="bgyellow" href="#"><span class="ico ico-friends"></span> Friends</a></li>
                <li><a class="bgpurple" href="/explore/" data-toggle="modal"><span class="ico ico-explore"></span> Explore</a></li>
                <!-- <li><a class="bggreen" href="/social-causes/"><span class="ico ico-causes"></span> Social causes</a></li> -->
                <li><a id="discover" class="bgaqua" href="#DiscoverMoreModal" data-toggle="modal"><span class="ico ico-discover"></span> Discover More</a></li>
            </ul>
        </div>

        <div class="sidebar_footer">
            <p><a class="livedemo fiesta clearfix" href="#"><span class="ico ico-demof"></span><span>Watch live demo</span></a></p>
            <p><a href="#">Help center</a> &bull; <a href="#">Privacy basics</a></p>
            <p>Destination Logs @ 2016</p>          
        </div>
     
    </aside>
</div>

<div class="mobile-discover-btn-wrapper hidden-lg hidden-md">
    <a class="" href="#" data-toggle="modal" data-target="#DiscoverMoreModal"><span class="ico ico-discover"></span></a>
</div>

<div id="DiscoverMoreModal" class="modal fade discover-more-dialog" tabindex="-1" role="dialog">
    <div class="modal-dialog styled-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span>Close</span><span class="icon"></span></button>
            </div>
            <div class="modal-body">
                <ul class="buttons-container discover-mobile-menu hidden-desktop">
                    <li class="full-width-sm"><a class="bgfiesta" href="/add-new/"><span class="ico ico-addnew"></span><span>New Log</span></a></li>
                    <li class="full-width-sm"><a class="bgyellow" href="/friends/"><span class="ico ico-friends"></span><span>Friends</span></a></li>
                    <li class="full-width-sm"><a class="bgpurple" href="/explore/"><span class="ico ico-explore"></span><span>Explore</span></a></li>                  
                 
                </ul>
            
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<style type="text/css">
    .fixed-sidebar {
        position: relative;
    }
    .fixed-sidebar aside {
        position: fixed;
        width: 175px;
    }
    @media (max-width: 991px) and (min-width: 980px) {
        .fixed-sidebar aside {
            width: 135px;
        }
    }
    .mobile-discover-btn-wrapper {
        position: fixed;
        bottom: 10px;
        right: 10px;
        width: 65px;
        height: 65px;
        color: #fff !important;
        padding: 3px;
        border-radius: 50%;
        overflow: hidden;
        z-index: 9;
    }
    .mobile-discover-btn-wrapper .ico {
        margin: 0;
        width: 100%;
        height: 100%;
        background-size: contain;
    }
    .styled-dialog button.close {
        padding: 0;
        background-color: transparent;
        border: none;
        opacity: 1;
    }
    .styled-dialog button.close span {
        line-height: 25px;
        height: 25px;
        display: inline-block;
        vertical-align: top;
        font-weight: 500;
        text-transform: uppercase;
        color: #656766;
    }
    .styled-dialog button.close span.icon {
        background: url("<?php echo get_template_directory_uri(); ?>/img/close.png") center no-repeat;
        background-size: contain;
        width: 28px;
        height: 25px;
        display: inline-block;
        margin-left: 5px;
    }
    .discover-more-dialog .styled-dialog {

    }
    .discover-more-dialog .styled-dialog .modal-header {
        padding: 8px 15px 2px;
    }
    .discover-more-dialog .styled-dialog .modal-content {
        padding: 0;
        border: none;
    }
    .discover-more-dialog .styled-dialog .modal-content ul.buttons-container {
        display: flex;
        list-style-type: none;
        margin: 0 0 10px;
        padding: 0;
    }
    .discover-more-dialog ul.buttons-container li {
        flex-grow: 1;
        padding-left: 5px;
        padding-right: 5px;
        width: 100%;
    }
    .discover-more-dialog ul.buttons-container li:first-child {
        padding-left: 0;
    }
    .discover-more-dialog ul.buttons-container li:last-child {
        padding-right: 0;
    }
    .discover-more-dialog ul.buttons-container a {
        padding: 4px 6px;
        display: inline-block;
        width: 100%;
        border-radius: 6px;
        line-height: 24px;
        font-weight: 400;
        text-align: center;
    }
    .discover-more-dialog ul.buttons-container a.bdaqua {
        border: 1px solid;
        padding: 3px 4px;
        background-color: #fff;
    }
    .discover-more-dialog ul.buttons-container a span {
        display: inline-block;
        line-height: 24px;
        height: 24px;
        vertical-align: top;
    }
    .discover-more-dialog ul.buttons-container a .ico {
        float: none;
        display: inline-block;
    }
    .discover-more-dialog .sections-container {
        display: flex;
        justify-content: space-between;
    }
    .discover-more-dialog section {
        width: 50%;
        box-sizing: border-box;
    }
    .discover-more-dialog section > div {
        border: 1px solid #fff;
        background-color: #f8f1e9;
        border-radius: 10px;
        overflow: hidden;
    }
    .discover-more-dialog section:first-child {
        margin-right: 5px;
    }
    .discover-more-dialog section:last-child {
        margin-left: 5px;
    }
    .discover-more-dialog section h4 {
        font-size: 18px;
        color: #0099ff;
        border-bottom: 1px solid #0099ff;
        margin: 10px 10px 0;
        padding: 0 5px 3px;
    }
    .discover-more-dialog section .destinations-container {
        padding: 5px 10px;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .discover-more-dialog section .destinations-container .item {
        display: flex;
        flex: none;
        flex-grow: 1;
        width: 50%;
        margin-bottom: 5px;
    }
    .discover-more-dialog section .destinations-container .item .image-section {
        border: 1px solid #fff;
        background: #fff;
        width: 70px;
        flex: none;
        margin: auto 5px auto 0;
    }
    .discover-more-dialog section .destinations-container .item .image-section img {
        width: 100%;
    }
    .discover-more-dialog section .destinations-container .item .description-section {
        display: flex;
        justify-content: center;
        flex-direction: column;
    }
    .discover-more-dialog section .destinations-container .item .description-section {
        font-size: 14px;
        line-height: 16px;
    }
    .discover-more-dialog section .destinations-container .item .description-section .city {
        color: #656766;
    }
    .discover-more-dialog section .destinations-container .item .description-section .country {
        color: #09f;
    }
    .discover-more-dialog section ul.buttons-container {
        margin: 5px 0 2px !important
    }
    .discover-more-dialog section .map-section {
        display: flex;
        flex-direction: column;
        height: 100%;
    }
    .discover-more-dialog section .map-section .map {
        flex-grow: 1;
        overflow: hidden;
        position: relative;
        min-height: 215px;
    }
    .discover-more-dialog section .map-section .map img {
        min-width: 100%;
        min-height: 100%;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }
    .discover-more-dialog section .map-section .location {
        background-color: #ecf1f4;
        border-top: 1px solid #fff;
        padding: 5px 10px;
        text-align: center;
    }
    .discover-more-dialog section .map-section .location span {
        color: #f66;
        font-size: 18px;
    }
    .discover-more-dialog section .map-section .title {
        background-color: #fec303;
        text-align: center;
        padding: 5px 10px;
    }
    .discover-more-dialog section .map-section .title span {
        color: #fff;
        font-size: 18px;
        line-height: 24px;
        display: inline-block;
        height: 24px;
        vertical-align: top;
    }
    .discover-more-dialog section .map-section .title .ico.ico-marker {
        background: url("<?php echo get_template_directory_uri(); ?>/img/temp/marker.png") center no-repeat;
        background-size: contain;
        float: none;
    }
    @media (min-width: 730px) {
        .hidden-desktop {
            display: none !important;
        }
    }
    @media (max-width: 800px) {
        .discover-more-dialog .styled-dialog {
            width: 100%;
        }
    }
    @media (max-width: 730px) {
        .hidden-mobile {
            display: none !important;
        }
        #DiscoverMoreModal.discover-more-dialog {
            background-color: #faf9f7 !important;
        }
        .discover-more-dialog ul.buttons-container {
            flex-wrap: wrap;
        }
        .discover-more-dialog ul.buttons-container li {
            width: 50%;
            flex: none;
            margin-bottom: 5px;
        }
        .discover-more-dialog ul.buttons-container.discover-mobile-menu li {
            padding-left: 0;
            padding-right: 0;
        }
        .discover-more-dialog ul.buttons-container li.full-width-sm {
            width: 100%;
            padding-left: 0 !important;
        }
/*        .discover-more-dialog ul.buttons-container.discover-mobile-menu li:nth-child(even){
            padding-right: 5px;
        }
        .discover-more-dialog ul.buttons-container.discover-mobile-menu li:nth-child(odd){
            padding-left: 5px;
        }*/
        .discover-more-dialog .sections-container {
            flex-wrap: wrap;
        }
        .discover-more-dialog section {
            width: 100%;
            flex: none;
            margin-bottom: 5px;
            margin-left: 0 !important;
            margin-right: 0 !important;
        }
        .discover-more-dialog section .destinations-container {
            justify-content: flex-start;
        }
        .discover-more-dialog section .destinations-container .item {
            width: 25%;
            flex: none;
        }
        .discover-more-dialog .styled-dialog .modal-content ul.buttons-container {
            width: 100%;
        }
        .mobile-order-1 {
            order: 1;
        }
        .mobile-order-2 {
            order: 2;
        }
        .discover-more-dialog ul.buttons-container a span {
            line-height: 32px;
            height: 32px;
        }
        .discover-more-dialog .styled-dialog button.close {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }
    }
    @media (max-width: 700px) {
        .discover-more-dialog section .destinations-container .item {
            width: 33.3%;
        }
    }
    @media (max-width: 600px) {
        .discover-more-dialog section .destinations-container .item {
            width: 50%;
        }
    }
    @media (max-width: 320px) {
        .discover-more-dialog section .destinations-container .item {
            width: 100%;
        }
    }
</style>

<?php endif; ?>