<?php
/**
 * Template name: Register
 *
 * @package _tk
 */

get_header(); ?>
    
<div id="registration">

<h1>Register</h1>

<?php while ( have_posts() ) : the_post(); ?>
	<?php the_content(); ?>
<?php endwhile;  ?>

</div>

<?php get_footer(); ?>
