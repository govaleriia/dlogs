<?php
/**
 * Template name: Map
 *
 * @package _tk
 */

get_header(); ?>

<?php // get_sidebar(); ?>

<div class="content">



    <div class="map-container">
        <div class="top-container">
            <div class="user-section bglblue">
                <div class="avatar-big">
                    <a href="/my-profile/"><?php bp_loggedin_user_avatar('type=full'); ?></a>
                </div>
                <div class="username">
                    <a href="/my-profile/">
                        <span class="icon icon-profile"></span>
                        <?php echo do_shortcode('[wpv-user field="user_firstname"]') . " " . do_shortcode('[wpv-user field="user_lastname"]'); ?>
                    </a>
                </div>
                <div class="dropdown">
                    <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="caret"></span>
                        2016
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                    </ul>
                </div>
            </div>

            <nav class="map-navbar navbar navbar-default bgaqua">
                <div class="navbar-container container-fluid">
                    <ul class="nav navbar-nav">
                        <li><a href="#" data-map-state="DESTINATIONS"><span class="icon icon-destinations"></span>Destinations</a></li>
                        <!-- <li><a href="#" data-map-state="MY_CITIES"><span class="icon icon-cities"></span>My Cities</a></li> -->
                        <li><a href="#" data-map-state="FRIENDS"><span class="icon icon-friends"></span>Friends</a></li>
                        <!-- <li><a href="#" data-map-state="BUCKET_LIST"><span class="icon icon-bucket"></span>Bucket list</a></li> -->
                        <!-- <li><a href="#" data-map-state="FAVORITES"><span class="icon icon-favorites"></span>Favorites</a></li> -->
                        <!-- <li><a href="#" data-map-state="MORE"><span class="icon icon-more"></span>More</a></li> -->
                    </ul>
                    <div id="search-map" class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-search" id="sizing-addon2"></span>
                        <input type="text" class="form-control" placeholder="Search destinations and friends..." aria-describedby="sizing-addon2">
                    </div>
                </div>
            </nav>
        </div>

        <div id="map"></div>
    </div>

</div>


<?php get_footer(); ?>
