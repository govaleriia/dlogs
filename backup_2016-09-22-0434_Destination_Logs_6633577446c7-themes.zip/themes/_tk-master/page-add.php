<?php
/**
 * Template name: Add new
 *
 * @package _tk
 */

get_header(); ?>

<?php get_sidebar(); ?>

<div id="content" class="content">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<div class="page-add">
			<header>
				<h1 class="page-title bgaqua"><?php the_title(); ?></h1>
			</header><!-- .entry-header -->

			<div class="entry-content">
				<?php the_content(); ?>
			</div><!-- .entry-content -->
			<?php edit_post_link( __( 'Edit', '_tk' ), '<footer class="entry-meta"><span class="edit-link">', '</span></footer>' ); ?>
			</div>
		</article><!-- #post-## -->

	<?php endwhile; // end of the loop. ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
