<?php

/**

 * Template name: Home New

 *

 * @package _tk

 */

get_header(); ?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/theme_styles_new.css'; ?>">

<?php get_sidebar(); ?>

<div id="content" class="content">
    <div class="faces bgaqua">
        <ul class="clearfix">
            <li>
                <a href="/profile/?user=6"><img src="<?php bloginfo('template_directory'); ?>/img/people/01.jpg" class="face">
                    <span>Claire</span></a>
            </li>
            <li>
                <img src="<?php bloginfo('template_directory'); ?>/img/people/02.jpg" class="face">
                <span>Tisha</span>
            </li>
            <li>
                <img src="<?php bloginfo('template_directory'); ?>/img/people/03.jpg" class="face">
                <span>Rob</span>
            </li>
            <li>
                <img src="<?php bloginfo('template_directory'); ?>/img/people/04.jpg" class="face">
                <span>Alina</span>
            </li>
            <li>
                <img src="<?php bloginfo('template_directory'); ?>/img/people/05.jpg" class="face">
                <span>Isabelle</span>
            </li>
            <li class="hide_on_mobile">
                <img src="<?php bloginfo('template_directory'); ?>/img/people/06.jpg" class="face">
                <span>Alan</span>
            </li>
            <li class="hide_on_mobile">
                <img src="<?php bloginfo('template_directory'); ?>/img/people/07.jpg" class="face">
                <span>Bea</span>
            </li>
            <li class="hide_on_tablet hide_on_mobile">
                <img src="<?php bloginfo('template_directory'); ?>/img/people/08.jpg" class="face">
                <span>John</span>
            </li>
            <li class="hide_on_tablet hide_on_mobile">
                <img src="<?php bloginfo('template_directory'); ?>/img/people/09.jpg" class="face">
                <span>Marry</span>
            </li>
        </ul>
    </div>

    <div class="tabs-bar styled-tabs">
        <ul class="nav nav-tabs bglaqua" role="tablist">
            <li class="active"><a href="#tab-1" aria-controls="tab-1" role="tab" data-toggle="tab" data-tab-name="new_logs"><span class="ico ico-travelogue"></span> <span>Destinations</span></a></li>
            <li><a href="#tab-2" aria-controls="tab-2" role="tab" data-toggle="tab"><span class="ico ico-friends"></span><span>Friends</span><span class="count"><?php bp_total_friend_count( bp_displayed_user_id() ); ?></span></a></li>
            <li><a href="#tab-3" aria-controls="tab-3" role="tab" data-toggle="tab" data-tab-name="favorites"><span class="ico ico-favorites"></span><span>Favorites</span></a></li>
        </ul>
    </div>

    <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="tab-1">
            <div class="feed bdaqua">             
                <?php echo do_shortcode('[wpv-view name="feed-latest-first-post-nd"]'); ?>
                <?php //echo do_shortcode('[wpv-view name="feed-latest"]'); ?>

                <div class="two_col_posts clearfix">
                    <div class="ajax-response"></div>
                </div>
                <div class="ajax-preloader">Loading...</div>
            </div>
        </div>
        <div role="tabpanel" class="tab-pane" id="tab-2">
            <div class="two_col_posts clearfix">
            <?php 
            if (is_user_logged_in()) {    
                $friend_ids = friends_get_friend_user_ids( bp_loggedin_user_id() );            
                if ( ! empty( $friend_ids )) {
                    $args = array(
                        'post_type' => 'log',
                        'author__in' => $friend_ids
                        ); 
                    $query = new WP_Query( $args );

                    if ( $query->have_posts() ) {                           
                    while ( $query->have_posts() ) {
                        $query->the_post();
                        echo do_shortcode('[wpv-post-body view_template="loop-item-in-feed-latest"]');
                    }



                } else {echo '<p>You have no friends of they haven\'t published anything yet. :(</p>';}

                wp_reset_postdata();

                } 



            } else {echo '<p>You need to login to see the posts of your friends.</p>';}

            ?> 

            </div>       

        </div>

        <div role="tabpanel" class="tab-pane" id="tab-3">
            <div class="two_col_posts clearfix">
                <div class="ajax-response"></div>
            </div>
            <div class="ajax-preloader">Loading...</div>
        </div>

    </div>



</div>



<script>

jQuery( function( $ ) {

    var adjust = function() {
        var width = $(window).width();
        var cover = $('#featured_cover');
        if (width > 600) {
            var totalH = $('.section-2').height();
            var thumbsH = $('.three_pics').width();
            cover.css('height', totalH -  (thumbsH-12)/3 - 10);
        } else if (width <= 600 && width > 400) {
            cover.css('height', '300px');
        } else if (width <= 400) {
            cover.css('height', '200px');
        }       
    }


    adjust();
    $(window).resize(function(){
        adjust();
    });

} );

</script>



<?php get_footer(); ?>

