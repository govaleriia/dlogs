<?php

/**
 * Template name: Form
 *
 * @package _tk
 */



get_header(); ?>
<link href='<?php echo get_template_directory_uri().'/style_form.css'; ?>' rel='stylesheet' type='text/css'>
<?php get_sidebar(); ?>
<div id="content" class="content">
	<?php while ( have_posts() ) : the_post(); ?>
		<?php the_content(); ?>		
	<?php endwhile; // end of the loop. ?>
</div>
<?php get_footer(); ?>
