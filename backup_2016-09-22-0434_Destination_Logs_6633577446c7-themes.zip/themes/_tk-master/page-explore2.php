<?php
/**
 * Template name: Explore HTML
 *
 * @package _tk
 */

get_header(); ?>

<?php get_sidebar(); ?>
    
<div id="content" class="content">

	<div class="explore-search bgaqua">
		<!-- <span class="ico ico-loupe_b"></span> -->
		<div class="wrap aqua"><span class="ico ico-loupe_b ico-left"></span>Enter destination and start exploring</div>
	</div>

	<div id="top_destinations">
		<h1>Featured destinations</h1>
		<div class="wrap clearfix">
			<div class="destination">
				<div class="image" style="background-image: url('<?php bloginfo('template_url'); ?>/img/temp/paris.jpg');"></div>
				<div class="name bgfiesta">Paris, France</div>
			</div>
			<div class="destination">
				<div class="image" style="background-image: url('<?php bloginfo('template_url'); ?>/img/temp/barcelona.jpg');"></div>
				<div class="name bgfiesta">Barcelona, Spain</div>
			</div>
			<div class="destination">
				<div class="image" style="background-image: url('<?php bloginfo('template_url'); ?>/img/temp/rio.jpg');"></div>
				<div class="name bgfiesta">Rio de Janeiro, Brazil</div>
			</div>
			<div class="destination">
				<div class="image" style="background-image: url('<?php bloginfo('template_url'); ?>/img/temp/paris.jpg');"></div>
				<div class="name bgfiesta">Paris, France</div>
			</div>
		</div>

		<div class="faces bgaqua">
		 	<h3>Kiara and 23456 other users like this</h3>
	        <ul class="clearfix">
	            <li>                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/01.jpg" class="face">
	                <span>Claire</span>
	            </li>
	            <li>                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/02.jpg" class="face">
	                <span>Tisha</span>
	            </li>
	            <li>                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/03.jpg" class="face">
	                <span>Rob</span>
	            </li>
	            <li>                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/04.jpg" class="face">
	                <span>Alina</span>
	            </li>
	            <li>                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/05.jpg" class="face">
	                <span>Isabelle</span>
	            </li>
	            <li class="hide_on_mobile">                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/06.jpg" class="face">
	                <span>Alan</span>
	            </li>
	            <li class="hide_on_mobile">                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/07.jpg" class="face">
	                <span>Bea</span>
	            </li>
	            <li class="hide_on_tablet">                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/08.jpg" class="face">
	                <span>John</span>
	            </li>
	            <li class="hide_on_tablet">                    
	                <img src="<?php bloginfo('template_directory'); ?>/img/people/09.jpg" class="face">
	                <span>Marry</span>
	            </li>
	        </ul>
	    </div>  

		<a class="more" href="#">View more</a>
	</div>

	<div id="deals">
		<h2>Sweetest deals</h2>
		<div class="wrap clearfix">
			<div class="deal-wrap">
				<div class="deal">					
					<div class="deal-header-wrap">
						<table class="deal-header">
						  	<tr>
							    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/whotel.png"></td>
							    <td class="captions">
						      		<p class="name">W Hotel</p>
						      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
						    	</td>
						  	</tr>
						</table>
					</div>				  	
					<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/whotelPromo.jpg');"></div>
					<div class="text">
						<h4 class="aqua">WEEKEND FOR 2</h4>
						<p>Come to the award winning W Hotel and enjoy a weekend far away from the husle.
						2 Nights / 1 Dinner for 2 / Tickets to 1 Summer Event.
						Valid from 15 july to 15 August.</p>
						<a href="" class="readmore">Read more</a>
					</div>
				</div>
			</div>

			<div class="deal-wrap">
				<div class="deal">					
					<div class="deal-header-wrap">
						<table class="deal-header">
						  	<tr>
							    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/aquaSpa.png"></td>
							    <td class="captions">
						      		<p class="name">Aqua Spa Therapy</p>
						      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
						    	</td>
						  	</tr>
						</table>
					</div>				  	
					<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/spa.png');"></div>
					<div class="text">
						<h4 class="aqua">Summer Spa Promotion</h4>
						<p>Enjoy our award winning Plenitude treatment promoting relaxation and renewal. 2 hours treatment with essential oils from Bali. 
						Reserved for 18 and older.</p>
						<a href="" class="readmore">Read more</a>
					</div>
				</div>
			</div>

			<div class="deal-wrap">
				<div class="deal">					
					<div class="deal-header-wrap">
						<table class="deal-header">
						  	<tr>
							    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/rafting.png"></td>
							    <td class="captions">
						      		<p class="name">KRAKATOA RAFTING</p>
						      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
						    	</td>
						  	</tr>
						</table>
					</div>				  	
					<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/rafting.jpg');"></div>
					<div class="text">
						<h4 class="aqua">UNFORGETTABLE RAFTING EXPERIENCE</h4>
						<p>Join our team of expert rafting guides for an unforgetable journey of four hours down the river Krakatoa. Starts at 8am / Food & Beverages provided.</p>
						<a href="" class="readmore">Read more</a>
					</div>
				</div>
			</div>

			<div class="deal-wrap">
				<div class="deal">					
					<div class="deal-header-wrap">
						<table class="deal-header">
						  	<tr>
							    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/temp/whotel.png"></td>
							    <td class="captions">
						      		<p class="name">Aqua Spa Therapy</p>
						      		<p class="location"><span class="aqua">Bali</span> <span class="dblue">Indonesia</span></p>
						    	</td>
						  	</tr>
						</table>
					</div>				  	
					<div class="cover" style="background-image:url('/wp-content/themes/_tk-master/img/temp/whotelPromo.jpg');"></div>
					<div class="text">
						<h4 class="aqua">WEEKEND FOR 2</h4>
						<p>Come to the award winning W Hotel and enjoy a weekend far away from the husle.
						2 Nights / 1 Dinner for 2 / Tickets to 1 Summer Event.
						Valid from 15 july to 15 August.</p>
						<a href="" class="readmore">Read more</a>
					</div>
				</div>				
			</div>			
		</div>
		<a class="more" href="#">View more</a>
	</div>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
