//http://jsfiddle.net/maunovaha/jptLfhc8/
function ZoomControl(controlDiv, map) {

    // Creating divs & styles for custom zoom control
    controlDiv.style.paddingBottom = '24px';

    // Set CSS for the control wrapper
    var controlWrapper = document.createElement('div');
    controlWrapper.style.backgroundColor = 'white';
    controlWrapper.style.borderStyle = 'solid';
    controlWrapper.style.borderColor = '#c2c2c2';
    controlWrapper.style.borderWidth = '1px';
    controlWrapper.style.borderRadius = '5px';
    controlWrapper.style.cursor = 'pointer';
    controlWrapper.style.textAlign = 'center';
    controlWrapper.style.width = '68px';
    controlWrapper.style.height = '32px';
    controlDiv.appendChild(controlWrapper);

    // Set CSS for the zoomIn
    var zoomInButton = document.createElement('span');
    zoomInButton.style.width = '32px';
    zoomInButton.style.height = '30px';
    zoomInButton.style.lineHeight = '30px';
    zoomInButton.style.top = 0;
    zoomInButton.style.borderRight = '1px solid #c2c2c2';
    zoomInButton.style.color = '#666666';
    zoomInButton.className = 'glyphicon glyphicon-plus';
    controlWrapper.appendChild(zoomInButton);

    // Set CSS for the zoomOut
    var zoomOutButton = document.createElement('span');
    zoomOutButton.style.width = '32px';
    zoomOutButton.style.height = '30px';
    zoomOutButton.style.lineHeight = '30px';
    zoomOutButton.style.top = 0;
    zoomOutButton.style.borderLeft = '1px solid #c2c2c2';
    zoomOutButton.style.color = '#666666';
    zoomOutButton.className = 'glyphicon glyphicon-minus';
    controlWrapper.appendChild(zoomOutButton);

    // Setup the click event listener - zoomIn
    google.maps.event.addDomListener(zoomInButton, 'click', function() {
        map.setZoom(map.getZoom() + 1);
    });

    // Setup the click event listener - zoomOut
    google.maps.event.addDomListener(zoomOutButton, 'click', function() {
        map.setZoom(map.getZoom() - 1);
    });

}
