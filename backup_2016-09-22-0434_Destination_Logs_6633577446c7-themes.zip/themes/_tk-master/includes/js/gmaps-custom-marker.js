function CustomMarker(latlng, map, args) {
    this.latlng = latlng;
    this.args = args;
    this.setMap(map);
}

CustomMarker.prototype = new google.maps.OverlayView();

CustomMarker.prototype.draw = function() {

    var self = this;

    var div = this.div;

    if (!div) {

        div = this.div = document.createElement('div');

        div.className = 'custom_marker';

        div.style.position = 'absolute';
        div.style.cursor = 'pointer';

        if (typeof(self.args.img_url) !== 'undefined' &&
            typeof(self.args.img_width) !== 'undefined' &&
            typeof(self.args.img_height) !== 'undefined' &&
            typeof(self.args.border_width) !== 'undefined') {
            div.style.backgroundImage = 'url("' + self.args.img_url + '")';
            div.style.backgroundSize = self.args.img_width + 'px ' + self.args.img_height + 'px';
            div.style.width = self.args.img_width + self.args.border_width * 2 + 'px';
            div.style.height = self.args.img_height + self.args.border_width * 2 + 'px';
        }

        if (typeof(self.args.border_color) !== 'undefined' &&
            typeof(self.args.border_width) !== 'undefined' &&
            typeof(self.args.border_radius) !== 'undefined') {
            div.style.border = self.args.border_width + 'px solid ' + self.args.border_color;
            div.style.borderRadius = self.args.border_radius + 'px';
        }

        if (typeof(self.args.post_count) !== 'undefined' && self.args.post_count !== 1) {
            div.innerHTML = '<span class="badge">' + self.args.post_count + '</span>';
        }

        google.maps.event.addDomListener(div, "click", function(event) {
            self.onClick();
        });

        var panes = this.getPanes();
        panes.overlayImage.appendChild(div);
    }

    var point = this.getProjection().fromLatLngToDivPixel(this.latlng);

    if (point &&
        typeof(self.args.img_width) !== 'undefined' &&
        typeof(self.args.img_height) !== 'undefined' &&
        typeof(self.args.border_width) !== 'undefined') {
        div.style.left = (point.x - self.args.img_width / 2 - self.args.border_width) + 'px';
        div.style.top = (point.y - self.args.img_height / 2 - self.args.border_width) + 'px';
    }
};

CustomMarker.prototype.remove = function() {
    if (this.div) {
        this.div.parentNode.removeChild(this.div);
        this.div = null;
    }
};

CustomMarker.prototype.getPosition = function() {
    return this.latlng;
};

CustomMarker.prototype.onClick = function() {
    google.maps.event.trigger(self, "click");
};
