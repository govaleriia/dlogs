var MapState = {
    ABOUT_ME: "ABOUT_ME",
    DESTINATIONS: "DESTINATIONS",
    BUCKET_LIST: "BUCKET_LIST",
    FRIENDS: "FRIENDS",
    BUSINESSES: "BUSINESSES"
};
var bucketListIcon = "/wp-content/themes/_tk-master/includes/images/icons/bucketList.png";
var fromIcon = "/wp-content/themes/_tk-master/includes/images/icons/from.png";
var livesInIcon = "/wp-content/themes/_tk-master/includes/images/icons/livesIn.png";
var destinationIcon = "/wp-content/themes/_tk-master/includes/images/icons/destination.png";
var friendIcon = "/wp-content/themes/_tk-master/includes/images/icons/friend.png";
var currentMapState;
var currentMapZoom;
var map;
var markerClusterer;
var infoWindow;
var geocoder;

var aboutMeMarkers = [];
var destinationMarkers = [];
var destinationAdditionalMarkers = [];
var bucketListMarkers = [];

jQuery(document).on("click", ".map-navbar li a", function (e) {
    e.preventDefault();
    var newMapState = jQuery(this).data("mapState");
    if (newMapState !== currentMapState) {
        //currentMapState = newMapState;
        jQuery(this).parents("ul.nav").find("li").removeClass("active");
        jQuery(this).parents("li").addClass("active");
        //reDrawMap(currentMapState);
    }
});

function reDrawMap(sectionName) {
    if (typeof markerClusterer !== 'undefined') {
        markerClusterer.clearMarkers();
    }
    clearMarkers(aboutMeMarkers);
    clearMarkers(destinationMarkers);
    clearMarkers(bucketListMarkers);
    switch (sectionName) {
        case MapState.ABOUT_ME:
            console.info("ABOUT_ME");
            //addAboutMeMarkers();
            break;
        case MapState.DESTINATIONS:
            addDestinationsMarkers();
            break;
        case MapState.BUCKET_LIST:
            console.info("BUCKET_LIST");
            //addBucketListMarkers();
            break;
        default:
            break;
    }
}

function addAboutMeMarkers() {
    if (aboutMeMarkers.length === 0) {
        loadAboutMeMarkers();
    } else {
        setMapOnAll(aboutMeMarkers, map);
    }
}
function loadAboutMeMarkers() {
    jQuery.ajax({
        type: "GET",
        url: window.wp_data.ajax_url,
        data: {
            action: 'gmap_about_me',
            security: window.wp_data.ajax_nonce
        },
        success: function (response) {
            console.log(JSON.parse(response));
            var iconSize = new google.maps.Size(40, 40);
            var iconIn = getMarkerIcon(window.location.origin + livesInIcon, iconSize);
            var iconFrom = getMarkerIcon(window.location.origin + fromIcon, iconSize);
            var parsedResponse = JSON.parse(response);
            var markerInOptions = {
                id: 0,
                location: parsedResponse.in,
                icon: iconIn,
                overlay: null,
                label: "",
                content: ""
            };
            var markerFromOptions = {
                id: 1,
                location: parsedResponse.from,
                icon: iconFrom,
                overlay: null,
                label: "",
                content: ""
            };
            addMarkerFromString(geocoder, map, markerInOptions, aboutMeMarkers);
            addMarkerFromString(geocoder, map, markerFromOptions, aboutMeMarkers);
        }
    });
}

function addMarkerFromString(myGeocoder, myMap, markerInOptions, markersArray) {
    var address = markerInOptions.location;
    if (isEmpty(address)) {
        return;
    }
    if (address[0] !== "{" && address[address.length - 1] !== "}") {
        geocodeAddress(myGeocoder, myMap, markerInOptions, markersArray);
    } else {
        var indexOfSeparator = address.indexOf(',');
        var latitude = address.slice(1, indexOfSeparator);
        var longitude = address.slice(indexOfSeparator + 1, address.length - 1);
        var latLng = new google.maps.LatLng(latitude, longitude);
        addMarker(myMap, latLng, markerInOptions, markersArray);
    }
}

function geocodeAddress(myGeocoder, myMap, markerInOptions, markersArray) {
    myGeocoder.geocode({'address': markerInOptions.location}, function (results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
            addMarker(myMap, results[0].geometry.location, markerInOptions, markersArray);
        } else {
            alert('Geocode was not successful for the following reason: ' + status);
        }
    });
}

function addMarker(newObject, markersArray) {
    var marker = new CustomMarker(
        newObject.location,
        map,
        {
            border_color: newObject.overlay.border_color,
            border_width: newObject.overlay.border_width,
            border_radius: newObject.overlay.border_radius,
            img_url: newObject.icon.url,
            img_width: newObject.icon.scaledSize.width,
            img_height: newObject.icon.scaledSize.height,
            post_count: newObject.post_count
        }
    );
    marker.onClick = (function () {
        var myMarker = marker;
        //var content = newObject.content;
        var link = newObject.link;
        //var markerHeight = newObject.icon.scaledSize.height;
        //var markerBorderWidth = newObject.overlay.border_width;
        //var anchor = marker;
        return function () {
            Object.getPrototypeOf(myMarker).onClick.call(myMarker);
            //infoWindow.setOptions({pixelOffset: new google.maps.Size(0, -(markerHeight + markerBorderWidth) / 2)});
            //infoWindow.setContent(content);
            //infoWindow.open(map, anchor);
            //window.open(link);
        };
    })();
    markersArray.push(marker);
}

function addDestinationsMarkers() {
    if (destinationMarkers.length === 0) {
        loadDestinationsMarkers();
    } else {
        setMapOnAll(destinationMarkers, map);
        markerClusterer.addMarkers(destinationMarkers);
    }
}
function loadDestinationsMarkers() {
    var mapElement = document.getElementById('map');
    var params = {
        action: 'gmap_destinations',
        security: window.wp_data.ajax_nonce
    };
    if (mapElement.dataset.userId !== undefined) {
        params["userId"] = mapElement.dataset.userId;
    }
    if (mapElement.dataset.postId !== undefined) {
        params["postId"] = mapElement.dataset.postId;
    }
    if (mapElement.dataset.year !== undefined) {
        params["year"] = mapElement.dataset.year;
    }

    jQuery.ajax({
        type: "GET",
        url: window.wp_data.ajax_url,
        data: params,
        success: function (response) {
            var destinations = JSON.parse(response);
            var arr = [];
            for (var i = 0; i < destinations.length; i++) {
                if (mapElement.dataset.postId === undefined) {
                    addPostToDestinationsArray(arr, destinations[i]);
                }
                var businessesArray = destinations[i]["businesses"];
                if (businessesArray !== undefined) {
                    var arrayLength = businessesArray.length;
                    for (var j = 0; j < arrayLength; j++) {
                        createDestinationBusinessesMarkers(businessesArray[j]);
                    }
                }
            }
            createDestinationsMarkers(arr);
            //if (mapElement.dataset.postId === undefined) {
            markerClusterer.addMarkers(destinationMarkers);
            markerClusterer.addMarkers(destinationAdditionalMarkers);
            //}
            var allMarkers = destinationMarkers.concat(destinationAdditionalMarkers);
            map.fitBounds(getBounds(allMarkers));
            if (destinationMarkers.length === 1) {
                map.setZoom(map.getZoom() - 5);
            }
        }
    });
}

function addPostToDestinationsArray(array, post) {
    var lat = post.lat;
    var lng = post.lng;
    if (!isNumber(lng) || !isNumber(lat)) {
        return;
    }
    var postLocationName = post.city + " " + post.country;
    var latLng = new google.maps.LatLng(lat, lng);

    var postData = {
        title: post.title,
        link: post.link,
        thumbnail: post.thumbnail
    };
    for (var i = 0; i < array.length; i++) {
        if (array[i].locationName === postLocationName) {
            array[i].posts.push(postData);
            return;
        }
    }
    var newLocation = {
        locationName: postLocationName,
        location: latLng,
        posts: []
    };
    newLocation.posts.push(postData);
    array.push(newLocation);
}
function isNumber(value) {
    return !isNaN(parseFloat(value)) && isFinite(value);
}

function createDestinationBusinessesMarkers(additionalMarkerInfo) {
    var lat = additionalMarkerInfo.lat;
    var lng = additionalMarkerInfo.lng;
    if (!isNumber(lng) || !isNumber(lat)) {
        return;
    }
    var latLng = new google.maps.LatLng(lat, lng);

    var marker = {
        location: latLng,
        icon: getMarkerIcon(additionalMarkerInfo.photo, new google.maps.Size(40, 40)),
        overlay: {
            border_color: "#FF7674",
            border_width: 4,
            border_radius: 8
        },
        link: additionalMarkerInfo.link,
        post_count: 1
    };
    addMarker(marker, destinationAdditionalMarkers);
}

function createDestinationsMarkers(destinations) {
    for (var i = 0; i < destinations.length; i++) {
        var markerDestinationOptions = {
            location: destinations[i].location,
            icon: getMarkerIcon(destinations[i].posts[0].thumbnail, new google.maps.Size(40, 40)),
            overlay: {
                border_color: "#488fcd",
                border_width: 4,
                border_radius: 8
            },
            link: destinations[i].posts[0].link,
            post_count: destinations[i].posts.length,
            content: getMarkerContent(destinations[i].posts)
        };
        addMarker(markerDestinationOptions, destinationMarkers);
    }
}

function addBucketListMarkers() {
    if (bucketListMarkers.length === 0) {
        loadBucketListMarkers();
    } else {
        setMapOnAll(bucketListMarkers, map);
        markerClusterer.addMarkers(bucketListMarkers);
    }
}
function loadBucketListMarkers() {
    jQuery.ajax({
        type: "GET",
        url: window.wp_data.ajax_url,
        data: {
            action: 'gmap_bucket_list',
            security: window.wp_data.ajax_nonce
        },
        success: function (response) {
            //console.log(JSON.parse(response));
            var iconBucket = getMarkerIcon(window.location.origin + bucketListIcon, new google.maps.Size(40, 40));
            var bucketList = JSON.parse(response);
            for (var i = 0; i < bucketList.length; i++) {
                var markerBucketListOptions = {
                    id: i,
                    location: bucketList[i],
                    icon: iconBucket,
                    overlay: null,
                    label: "",
                    content: ""
                };
                addMarkerFromString(geocoder, map, markerBucketListOptions, bucketListMarkers);
            }
        }
    });
}

function getMarkerIcon(url, size, labelOrigin) {
    labelOrigin = typeof labelOrigin !== 'undefined' ? labelOrigin : new google.maps.Point(size.width / 2, size.height / 2);
    var image = {
        url: url,
        scaledSize: size,
        labelOrigin: labelOrigin
    };
    return image;
}

function getMarkerContent(posts) {
    var contentString = "";
    for (var i = 0; i < posts.length; i++) {
        contentString += '<div class="markerInfo">' +
            '<img src="' + posts[i].thumbnail + '" alt="' + posts[i].title + '" class="image">' +
            '<a href="' + posts[i].link + '" target="_blank">' + posts[i].title + '</a></div>';
    }
    return contentString;
}

function initMap() {
    currentMapZoom = 2;
    currentMapState = MapState.DESTINATIONS; //MapState.ABOUT_ME;
    var mapOptions = {
        center: {lat: 30, lng: 0},
        zoom: currentMapZoom,
        mapTypeControl: false,
        streetViewControl: false,
        zoomControl: false
    };
    var mapElement = document.getElementById('map');
    if (mapElement.dataset.mapState === MapState.BUSINESSES) {
        mapOptions["draggable"] = false;
        mapOptions["scrollwheel"] = false;
        mapOptions["disableDoubleClickZoom"] = true;
        mapElement.style.cursor = "pointer";
    }

    map = new google.maps.Map(document.getElementById('map'), mapOptions);
    map.mapTypes.set('styled_map', getStyledMapType());
    map.setMapTypeId('styled_map');

    if (mapElement.dataset.mapState !== MapState.BUSINESSES) {
        var zoomControlDiv = document.createElement('div');
        var zoomControl = new ZoomControl(zoomControlDiv, map);
        zoomControlDiv.index = 1;
        map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(zoomControlDiv);
    } else {
        map.addListener('click', function() {
            window.open(window.location.origin + "/map/", "_self");
        });
    }

    markerClusterer = new MarkerClusterer(map, [], {imagePath: 'https://googlemaps.github.io/js-marker-clusterer/images/m'});

    infoWindow = new google.maps.InfoWindow();
    geocoder = new google.maps.Geocoder();

    if (jQuery(".top-container .dropdown").length) {
        initYearsDropdown();
    } else {
        reDrawMap(currentMapState);
    }
}

function initYearsDropdown() {
    jQuery.ajax({
        type: "GET",
        url: window.wp_data.ajax_url,
        data: {
            action: 'gmap_destinations_years',
            security: window.wp_data.ajax_nonce
        },
        success: function (response) {
            var years = JSON.parse(response);
            var dropdown = jQuery(".top-container .dropdown .btn.btn-default.dropdown-toggle");
            dropdown.val(years[0]);
            jQuery("#map").attr("data-year", years[0]);
            for (var i = 0; i < years.length; i++) {
                jQuery(".top-container .dropdown .dropdown-menu")
                    .append('<li><a href="#" data-value="' + years[i] + '">' + years[i] + '</a></li>');
            }
            reDrawMap(currentMapState);
        }
    });
    jQuery(document).on("click", ".top-container .dropdown .dropdown-menu li a", function (e) {
        e.preventDefault();
        var dropdown = jQuery(this).parents(".dropdown").find(".btn.btn-default.dropdown-toggle");
        var currentYear = parseInt(dropdown.val());
        var newYear = parseInt(jQuery(this).data('value'));
        if (newYear !== currentYear) {
            dropdown.html('<span class="caret"></span> ' + jQuery(this).text());
            dropdown.val(newYear);
            jQuery("#map").attr("data-year", newYear);
            clearMarkers(destinationMarkers);
            destinationMarkers = [];
            reDrawMap(currentMapState);
        }
    });
}

function getStyledMapType() {
    // Theme: https://snazzymaps.com/style/151/ultra-light-with-labels
    return new google.maps.StyledMapType(
        [{
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{"color": "#e9e9e9"}, {"lightness": 17}]
        }, {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [{"color": "#f5f5f5"}, {"lightness": 20}]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.fill",
            "stylers": [{"color": "#ffffff"}, {"lightness": 17}]
        }, {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{"color": "#ffffff"}, {"lightness": 29}, {"weight": 0.2}]
        }, {
            "featureType": "road.arterial",
            "elementType": "geometry",
            "stylers": [{"color": "#ffffff"}, {"lightness": 18}]
        }, {
            "featureType": "road.local",
            "elementType": "geometry",
            "stylers": [{"color": "#ffffff"}, {"lightness": 16}]
        }, {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{"color": "#f5f5f5"}, {"lightness": 21}]
        }, {
            "featureType": "poi.park",
            "elementType": "geometry",
            "stylers": [{"color": "#dedede"}, {"lightness": 21}]
        }, {
            "elementType": "labels.text.stroke",
            "stylers": [{"visibility": "on"}, {"color": "#ffffff"}, {"lightness": 16}]
        }, {
            "elementType": "labels.text.fill",
            "stylers": [{"saturation": 36}, {"color": "#333333"}, {"lightness": 40}]
        }, {
            "featureType": "transit",
            "elementType": "geometry",
            "stylers": [{"color": "#f2f2f2"}, {"lightness": 19}]
        }, {
            "featureType": "transit.station",
            "stylers": [{"visibility": 'off'}]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.fill",
            "stylers": [{"color": "#fefefe"}, {"lightness": 20}]
        }, {
            "featureType": "administrative",
            "elementType": "geometry.stroke",
            "stylers": [{"color": "#fefefe"}, {"lightness": 17}, {"weight": 1.2}]
        }],
        {name: 'Styled Map'});
}

// Removes the markers from the map, but keeps them in the array.
function clearMarkers(markers) {
    setMapOnAll(markers, null);
}
// Sets the map on all markers in the array.
function setMapOnAll(markers, myMap) {
    for (var i = 0; i < markers.length; i++) {
        markers[i].setMap(myMap);
    }
}
// Return true if string is empty
function isEmpty(str) {
    return (!str || 0 === str.length);
}

// Returns the bounds of markers array.
function getBounds(markers) {
    var bounds = new google.maps.LatLngBounds(this.center_, this.center_);
    for (var i = 0, marker; marker = markers[i]; i++) {
        bounds.extend(marker.getPosition());
    }
    return bounds;
}
