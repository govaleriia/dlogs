$(function(){

    console.log("Page loaded");

    $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            items: 1,
            margin: 10
        });
    });

});