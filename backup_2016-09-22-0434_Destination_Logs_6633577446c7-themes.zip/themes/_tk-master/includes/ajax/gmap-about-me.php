<?php
add_action('wp_ajax_gmap_about_me', 'get_about_me_callback');
add_action('wp_ajax_nopriv_gmap_about_me', 'get_about_me_callback');

function get_about_me_callback()
{
    check_ajax_referer(NONCE_STRING, 'security');
    $user_id = get_current_user_id();
    $result = array(
        "in" => get_user_meta($user_id, 'wpcf-lives-in-full', true),
        "from" => get_user_meta($user_id, 'wpcf-from-full', true)
    );
    echo(json_encode($result));
    wp_die();
}
