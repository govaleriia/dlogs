<?php
add_action('wp_ajax_gmap_bucket_list', 'get_bucket_list_callback');
add_action('wp_ajax_nopriv_gmap_bucket_list', 'get_bucket_list_callback');

function get_bucket_list_callback()
{
    check_ajax_referer(NONCE_STRING, 'security');
    echo(json_encode(get_user_meta(get_current_user_id(), 'wpcf-bucket-list')));
    wp_die();
}
