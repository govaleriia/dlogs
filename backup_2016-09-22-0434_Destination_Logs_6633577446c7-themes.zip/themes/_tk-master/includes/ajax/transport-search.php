<?php

define("AJAX_URL", "admin-ajax.php");
define("NONCE_STRING", "nonce-string");
define("TYPE_AIRLINE", "airline");
define("TYPE_TRAIN", "train");
define("TYPE_SHIP", "ship");
define("TYPE_CAR", "car");

function set_js_variables()
{
    $variables = array(
        'ajax_url' => admin_url(AJAX_URL),
        'ajax_nonce' => wp_create_nonce(NONCE_STRING)
    );
    echo '<script type="text/javascript">window.wp_data = ' . json_encode($variables) . ';</script>';
}

add_action('wp_head', 'set_js_variables');

add_action('wp_ajax_get_transport', 'get_transport_callback');
add_action('wp_ajax_nopriv_get_transport', 'get_transport_callback');

function get_transport_callback()
{
    check_ajax_referer(NONCE_STRING, 'security');
    $type = wp_filter_nohtml_kses($_GET['type']);
    $value = wp_filter_nohtml_kses($_GET['inputValue']);
    echo(json_encode(get_search_result($type, $value)));
    wp_die();
}

function get_search_result($type, $value)
{
    $fuzzySearchResults = array();
    $searchResults = array();
    $args = array(
        'post_type' => $type,
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'suppress_filters' => true
    );
    $query = new WP_Query($args);
    while ($query->have_posts()) {
        $query->the_post();
        if (is_fuzzy_coincidence($value, get_the_title())) {
            $fuzzySearchResults[] = array(
                "id" => get_the_ID(),
                "title" => get_the_title(),
                "raw" => $value
            );
        }
        if ((strpos(trim($value), ' ') === false) && (strpos(trim(get_the_title()), ' ') !== false)) {
            $wordsFromTitle = explode(" ", get_the_title());
            foreach ($wordsFromTitle as $word) {
                if (is_fuzzy_coincidence($value, $word)) {
                    $fuzzySearchResults[] = array(
                        "id" => get_the_ID(),
                        "title" => get_the_title(),
                        "raw" => $value
                    );
                }
            }
        }
        if (is_coincidence($value, get_the_title())) {
            $searchResults[] = array(
                "id" => get_the_ID(),
                "title" => get_the_title(),
                "raw" => get_the_title()
            );
        }
    }
    wp_reset_postdata();
    return array_merge($fuzzySearchResults, array_slice($searchResults, 0, 7 - count($fuzzySearchResults), true));
}

function is_fuzzy_coincidence($myWord, $anotherWord)
{
    if (levenshtein(metaphone($myWord), metaphone($anotherWord)) < mb_strlen(metaphone($myWord)) * 0.65) {
        if (levenshtein($myWord, $anotherWord) < mb_strlen($myWord) * 0.65) {
            return true;
        }
    }
    return false;
}

function is_coincidence($myWord, $anotherWord)
{
    if (stristr($anotherWord, $myWord) !== FALSE) {
        return true;
    }
    return false;
}
