<?php
add_action('wp_ajax_gmap_destinations', 'get_destinations_callback');
add_action('wp_ajax_nopriv_gmap_destinations', 'get_destinations_callback');

define("PLACEHOLDER", get_bloginfo('template_url') . "/img/map/marker_placeholder.png");

function get_destinations_callback()
{
    check_ajax_referer(NONCE_STRING, 'security');

    if (isset($_GET['postId'])) {
        $postId = $_GET['postId'];
        echo(json_encode(getDestinationByPostId($postId)));
    } else {
        if (isset($_GET['year'])) {
            $userId = get_current_user_id();
            $year = $_GET['year'];
            echo(json_encode(getDestinationByYear($userId, $year)));
        } else {
            if (isset($_GET['userId'])) {
                $userId = $_GET['userId'];
            } else {
                $userId = get_current_user_id();
            }
            echo(json_encode(getAllDestinationsByUserId($userId)));
        }
    }
    wp_die();
}

function getDestinationByYear($userId, $year)
{
    $results = array();
    $args = array(
        'author' => $userId,
        'post_type' => 'log',
        'posts_per_page' => -1
    );
    $query = new WP_Query($args);
    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();

        $date = get_post_meta($post_id, 'wpcf-arrival-date', true);
        if (!empty($date) && (($timestamp = strtotime($date)) !== false)) {
            $php_date = getdate($timestamp);
            $postYear = $php_date[year];
            if ($year == $postYear) {
                $thumbnail_url = get_the_post_thumbnail_url($post_id);
                if (!empty($thumbnail_url)) {
                    $post_thumbnail_url = getThumbnailBySize($thumbnail_url, "150x150");
                } else {
                    $post_thumbnail_url = PLACEHOLDER;
                }
                $results[] = array(
                    "title" => get_the_title($post_id),
                    "link" => get_the_permalink($post_id),
                    "thumbnail" => $post_thumbnail_url,
                    "country" => get_post_meta($post_id, 'wpcf-location-country', true),
                    "city" => get_post_meta($post_id, 'wpcf-location-city', true),
                    "lng" => get_post_meta($post_id, 'wpcf-location-lng', true),
                    "lat" => get_post_meta($post_id, 'wpcf-location-lat', true)
                );
            }
        }
    }
    return $results;
}

function getDestinationByPostId($post_id)
{
    $thumbnail_url = get_the_post_thumbnail_url($post_id);
    if (!empty($thumbnail_url)) {
        $post_thumbnail_url = getThumbnailBySize($thumbnail_url, "150x150");
    } else {
        $post_thumbnail_url = PLACEHOLDER;
    }

    $results = array();
    $results[] = array(
        "title" => get_the_title($post_id),
        "link" => get_the_permalink($post_id),
        "thumbnail" => $post_thumbnail_url,
        "country" => get_post_meta($post_id, 'wpcf-location-country', true),
        "city" => get_post_meta($post_id, 'wpcf-location-city', true),
        "lng" => get_post_meta($post_id, 'wpcf-location-lng', true),
        "lat" => get_post_meta($post_id, 'wpcf-location-lat', true),
        "businesses" => getAdditionalPlaces($post_id, array('shopping', 'restaurants', 'accommodations', 'bars-clubs', 'sightseeings', 'fun-things-to-do', 'cafes'))
    );
    return $results;
}

function getAdditionalPlaces($post_id, $metaNames) {
    $result = array();
    foreach($metaNames as $metaName) {
        $places = json_decode(get_post_meta($post_id, $metaName, true));
        foreach($places as $place) {
            $place_thumbnail_url = getPhotoByLink($place->link);
            if (!empty($place_thumbnail_url)) {
                $photo = getThumbnailBySize($place_thumbnail_url, "150x150");
            } else {
                $photo = PLACEHOLDER;
            }
            $result[] = array(
                "title" => $place->name,
                "link" => $place->link,
                "photo" => $photo,
                "lat" => $place->lat,
                "lng" => $place->lng
            );
        }
    }
    return $result;
}

function getAllDestinationsByUserId($userId)
{
    $results = array();
    $args = array(
        'author' => $userId,
        'post_type' => 'log',
        'posts_per_page' => -1
    );
    $query = new WP_Query($args);
    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();

        $thumbnail_url = get_the_post_thumbnail_url();
        if (!empty($thumbnail_url)) {
            $post_thumbnail_url = getThumbnailBySize($thumbnail_url, "150x150");
        } else {
            $post_thumbnail_url = PLACEHOLDER;
        }

        $post_country = get_post_meta($post_id, 'wpcf-location-country', true);
        $post_city = get_post_meta($post_id, 'wpcf-location-city', true);
        if (!empty($post_country) && !empty($post_city)) {
            $results[] = array(
                "title" => get_the_title(),
                "link" => get_the_permalink(),
                "thumbnail" => $post_thumbnail_url,
                "country" => $post_country,
                "city" => $post_city,
                "lng" => get_post_meta($post_id, 'wpcf-location-lng', true),
                "lat" => get_post_meta($post_id, 'wpcf-location-lat', true)
            );
        }
    }
    return $results;
}

function getThumbnailBySize($url, $size)
{
    if (empty($url)) {
        return "";
    }
    $path_parts = pathinfo($url);
    return $path_parts['dirname'] . "/" . $path_parts['filename'] . "-" . $size . "." . $path_parts['extension'];
}

function getUsername($url)
{
    $url = rtrim($url, "/");
    $parts = explode("/", $url);
    return end($parts);
}

function getPhotoByLink($url)
{
    global $wpdb;
    $username = getUsername($url);
    $user = get_user_by('login', $username);
    $photos = get_user_meta($user->ID, 'photos', true);
    if (!empty($photos)) {
        $photos = explode("{", $photos);
        $photos = explode("}", $photos[1]);
        $photos = explode(';', $photos[0]);
        foreach ($photos as $key => $value) {
            if ($key % 2 == 0)
                unset($photos[$key]);
            else {
                $photos[$key] = substr($value, 2);
            }
        }
        $photos = array_values($photos);
        $result = $wpdb->get_results('SELECT meta_value FROM ' . $wpdb->prefix . 'postmeta WHERE post_id = ' . current($photos) . ' AND meta_key = "_wp_attached_file"');
        $photoUrl = get_site_url() . "/wp-content/uploads/" . $result[0]->meta_value;
        return $photoUrl;
    }
    return "";
}
