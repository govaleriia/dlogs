<?php
add_action('wp_ajax_gmap_destinations_years', 'get_destinations_years_callback');
add_action('wp_ajax_nopriv_gmap_destinations_years', 'get_destinations_years_callback');

function get_destinations_years_callback()
{
    check_ajax_referer(NONCE_STRING, 'security');
    echo(json_encode(getAllDestinationYearsByUserId(get_current_user_id())));
    wp_die();
}

function getAllDestinationYearsByUserId($userId)
{
    $results = array();
    $args = array(
        'author' => $userId,
        'post_type' => 'log',
        'posts_per_page' => -1
    );
    $query = new WP_Query($args);
    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();

        $date = get_post_meta($post_id, 'wpcf-arrival-date', true);
        if (!empty($date) && (($timestamp = strtotime($date)) !== false)) {
            $php_date = getdate($timestamp);
            $results[] = $php_date[year];
        }
    }
    $results = array_unique($results);
    rsort($results);
    return $results;
}
