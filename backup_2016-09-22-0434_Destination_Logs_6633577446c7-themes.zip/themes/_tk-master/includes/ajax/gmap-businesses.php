<?php
add_action('wp_ajax_gmap_businesses', 'get_businesses_callback');
add_action('wp_ajax_nopriv_gmap_businesses', 'get_businesses_callback');

function get_businesses_callback()
{
    if(isset($_GET['userId'])) {
        $userId = $_GET['userId'];
    } else {
        $userId = get_current_user_id();
    }
    check_ajax_referer(NONCE_STRING, 'security');
    $results = array();
    $args = array(
        'author' => $userId,
        'post_type' => 'log',
        'posts_per_page' => -1
    );
    $query = new WP_Query($args);
    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();

        $thumbnail_url = get_the_post_thumbnail_url();
        $post_thumbnail_url = "";
        if (!empty($thumbnail_url)) {
            $path_parts = pathinfo($thumbnail_url);
            $post_thumbnail_url = $path_parts['dirname'] . "/" . $path_parts['filename'] . "-150x150." . $path_parts['extension'];
        }

        $post_country = get_post_meta($post_id, 'wpcf-country', true);
        $post_city = get_post_meta($post_id, 'wpcf-city', true);
        if (!empty($post_country) && !empty($post_city)) {
            $results[] = array(
                "title" => get_the_title(),
                "link" => get_the_permalink(),
                "thumbnail" => $post_thumbnail_url,
                "country" => $post_country,
                "city" => $post_city,
                "lng" => get_post_meta($post_id, 'wpcf-location-lng', true),
                "lat" => get_post_meta($post_id, 'wpcf-location-lat', true)
            );
        }
    }
    echo(json_encode($results));
    wp_die();
}
