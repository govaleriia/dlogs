<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package _tk
 */
?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri() . '/theme_styles_new.css'; ?>">

<style>

.profile>.cover {height: 304px;background-position: center;background-size: cover;}
.change_cover {position: absolute;top: 50px;right: 14px;width: 28px;opacity: 0.8;}
.change_avatar {position: absolute;top: 12px;right: 12px;width: 28px;opacity: 0.8;}
.avatar {position: relative;}
@media only screen and (max-width: 500px) {
	.profile>.cover {height: 200px;}
}
</style>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="profile">

		<div class="cover" style="width: 100%; background-image: url(<?php echo do_shortcode('[types usermeta="cover" size="full" url="true" user_current="true"][/types]'); ?>);">
			<!--<img src="http://dl.nexdna.com/wp-content/themes/_tk-master/img/share_cover.png" class="addfriend">
			<img src="http://dl.nexdna.com/wp-content/themes/_tk-master/img/camera.png" class="change_cover">-->
			<?php // echo do_shortcode('[wp_ulike]'); ?>
			<div class="user-profile-info">
				<div class="avatar-big">
					<a href="/my-profile/"><?php bp_loggedin_user_avatar( 'type=full' ); ?></a>
				</div>
				<div class="user-info">
					<div class="user-name">
						<span><a href="/my-profile/"><?php echo do_shortcode('[wpv-user field="user_firstname"]'); ?></a></span>
					</div>
					<div class="user-title">
						<span>Status</span>
						<span class="font-bold">Wanderlust</span>
					</div>
				</div>
			</div>
		</div>
<div id="map"></div>

		<div class="tabs-bar styled-tabs">
	        <ul class="nav nav-tabs" role="tablist">
	        <?php $user_id = do_shortcode('[wpv-user field="ID"]'); ?>
	            <li class="active">
					<a href="#tab-1" aria-controls="tab-1" role="tab" data-toggle="tab"><span class="ico ico-travelogue"></span> <span>Destinations</span> <span class="count"><?php echo count_user_posts( $user_id , "log"  ); ?></span></a>
				</li>
	            <!-- <li><a href="#tab-2" aria-controls="tab-2" role="tab" data-toggle="tab"><span class="ico ico-city"></span><span>My city</span><span class="count">2</span></a></li> -->
	            <li><a href="#tab-3" aria-controls="tab-3" role="tab" data-toggle="tab"><span class="ico ico-friends"></span><span>Friends</span><span class="count"><?php bp_total_friend_count( bp_displayed_user_id() ); ?></span></a></li>


	            <?php global $wpdb;
	             
	                $likes_by_user_query = 'SELECT COUNT(post_id) FROM '. $wpdb->prefix . 'ulike WHERE user_id = ' . do_shortcode('[wpv-user field="ID"]') . ' AND status = "like"';
	                $likes_by_user = $wpdb->get_results( $likes_by_user_query, ARRAY_N);                 
	            
	            ?>
	            <li><a href="#tab-4" aria-controls="tab-4" role="tab" data-toggle="tab"><span class="ico ico-favorites"></span><span>Favorites</span><span class="count"><?php echo $likes_by_user[0][0]; ?></span></a></li>
	            <!-- <li><a href="#tab-3" aria-controls="tab-3" role="tab" data-toggle="tab"><span class="ico ico-loupe"></span></a></li> -->
				<!-- <li class="small-tab">
					<div class="dropdown">
						<a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="ico ico-more"></span><span>More</span></a>
						<ul class="dropdown-menu" aria-labelledby="dLabel">
							<li><a href="#">More 1</a></li>
							<li><a href="#">More 2</a></li>
							<li><a href="#">More 3</a></li>
						</ul>
					</div>
				</li> -->
	        </ul>
	    </div>

		<div class="tab-content">
	        <div role="tabpanel" class="tab-pane active bdaqua" id="tab-1">
				
	        	<div class="two_col_posts clearfix">
			        <?php

			        	$args = array(
		                    'post_type' => 'log',
		                    'author' => $user_id
		                    ); 
		                $query = new WP_Query( $args );

		                if ( $query->have_posts() ) {                           
		                    while ( $query->have_posts() ) {
		                        $query->the_post();
		                        echo do_shortcode('[wpv-post-body view_template="loop-item-in-feed-latest"]');
		                    }
		                }
		                wp_reset_postdata();
		            ?>
            	</div>

	        </div>
	        <div role="tabpanel" class="tab-pane bdaqua" id="tab-2"> </div>
	        <div role="tabpanel" class="tab-pane bdaqua" id="tab-3"> </div>
	        <div role="tabpanel" class="tab-pane bdaqua" id="tab-4">
	        	<div class="two_col_posts clearfix">
		        	<?php if (is_user_logged_in()) {

	                global $wpdb;
	                $string = 'SELECT post_id FROM '. $wpdb->prefix . 'ulike WHERE user_id = ' . do_shortcode('[wpv-user field="ID"]') . ' AND status = "like"';
	                $liked = $wpdb->get_results( $string, ARRAY_N);       
	                $liked_ids =  array();
	                foreach ($liked as $value) {
	                    $liked_ids[] = $value[0];
	                }

	                $args = array(
	                    'post_type' => 'log',
	                    'post__in' => $liked_ids
	                    ); 
	                $query = new WP_Query( $args );

	                if ( $query->have_posts() ) {                         
	                    while ( $query->have_posts() ) {
	                        $query->the_post();
	                        echo do_shortcode('[wpv-post-body view_template="loop-item-in-feed-latest"]');
	                    }
	                }
	                wp_reset_postdata();
	            } else {
	                echo '<p>You need to login to see your favorite posts.</p>';

	            }

	            ?>
            </div>
	        </div>
	        <!-- <div role="tabpanel" class="tab-pane bdaqua" id="tab-4"> </div> -->


        </div>
	</div>
</article><!-- #post-## -->
