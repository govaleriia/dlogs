<?php
/**
 * Template name: Geolocation
 *
 * @package _tk
 */

get_header(); ?>

<?php get_sidebar(); ?>
    
<div id="content" class="content">

<style>
@charset "utf-8";
html{
    background:#222222;
    font-family:helvetica, arial, sans-serif;
}
.wrapper{
    width:960px;
    margin: 0 auto;
    position:relative;
}
#map{
    position:relative;
    text-align: center;
    color: #363535;
    text-transform: uppercase;
    width: 425px;
    height: 350px;
    margin:0 auto;
    margin-top:20px;
    padding: 5px;
    border: 1px solid black;
    background: #474747;
    box-shadow: 0px 0px 3px 3px rgba(0, 0, 0, .3);
}
#map .helper{
    display: block;
    font-weight: bold;
    font-size: 12px;
    color: rgb(54, 54, 54);
    width: 180px;
    line-height: 135%;
    margin: 0 auto;
    margin-top: 140px;
}
#map #preloader{
    position: absolute;
    top: 141px;
    left: 190px;
    display:none;
}
#map iframe{
    border:1px solid black;
}
.button{
    padding:13px 40px;
    background-color:#00caa7;
    color:#00caa7;
    border-radius:3px;
    color:white;
    display:block;
    text-decoration:none;
    box-shadow: inset 0px 1px 0px rgba(255, 255, 255, 0.3);
    width:122px;
    margin:0 auto;
    margin-top:20px;
}
.button:hover{
    background-color:#00b495
}
#results{
    color: rgb(0, 180, 149);
    position: absolute;
    margin-top: 20px;
    text-align: center;
    line-height: 23px;
    width: 100%;
}

</style>

	<div class="wrapper">
 
	    <div id="map">
	        <span class="helper">Click the button below to show your location on the map</span>
	    </div>
	 
	    <a class="button" href="" title="">Find My Location</a>
	 
	    <div id="results">
	        <span class="longitude"></span><br>
	        <span class="lattitude"></span><br>
	        <span class="location"></span>
	    </div>
	     
	</div><!--End Wrapper-->

</div>

<script>

var button = jQuery('.button');
var preloader = jQuery('#preloader');
var longitudediv = jQuery('.longitude');
var lattitudediv = jQuery('.lattitude');
var locationdiv = jQuery('.location');
var pretext;
var latitude;
var longitude;

if (navigator.geolocation) {    
    	button.click(function(e) {
		    e.preventDefault();
		    preloader.show();
		    navigator.geolocation.getCurrentPosition(exportPosition, errorPosition);
		});    	  
    } else {    
    alert('Sorry your browser doesn\'t support the Geolocation API');    
}

function errorPosition() {                  
    alert('Sorry couldn\'t find your location');                 
    pretext.show();         
}

function exportPosition(position) {
 
    // Get the geolocation properties and set them as variables
    latitude = position.coords.latitude;
    longitude  = position.coords.longitude;
 
    // Insert the google maps iframe and change the location using the variables returned from the API
    jQuery('#map').html('<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.co.uk/?ie=UTF8&amp;ll='+latitude+','+longitude+'&amp;spn=0.332359,0.617294&amp;t=m&amp;z=11&amp;output=embed"></iframe>');
    longitudediv.html('Longitude: '+longitude);
    lattitudediv.html('Latitude: '+latitude);
     
}

//Make a call to the Google maps api to get the name of the location
    jQuery.ajax({
      url: 'http://maps.googleapis.com/maps/api/geocode/json?latlng='+latitude+','+longitude+'&sensor=true',
      type: 'POST',
      dataType: 'json',
      success: function(data) {
        //If Successful add the data to the 'location' div
     locationdiv.html('Location: '+data.results[0].address_components[2].long_name);
      },
      error: function(xhr, textStatus, errorThrown) {
             errorPosition();
      }
    });



</script>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
