<?php
/**
 * Template name: City
 *
 * @package _tk
 */

get_header(); ?>

<?php get_sidebar(); ?>
    
<div id="content" class="content">

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="bizprofile city">
		<div class="biz-wrap bdaqua">
			<table class="item-header">
			  <tr>
			    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/flags/indonesia.png"></td>
			    <td class="captions">
			      <p class="name semi">Bali</p>
			      <p class="location bold">Indonesia</p>
			    </td>
			    <td class="actions">
			    	<table>
			    		<tr>
			    			<td></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/shared.png" class="icon"></td>
			    		</tr>
			    		<tr>
			    			<td><span class="love_counter">23987</span></td>
			    			<td><img src="/wp-content/themes/_tk-master/img/love/love.png" class="icon"></td>
			    		</tr>
			    	</table>
			    </td>
			  </tr>
			</table>
			<div class="gallery clearfix">
				<div class="featured">
					<div class="image" style="background-image: url('/wp-content/themes/_tk-master/img/bizPimages/video.jpg');"></div>
				</div>
				<div class="thumbs">
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/themes/_tk-master/img/bizPimages/img01.jpg');margin: 2px 0 2px 2px;"></div>
					</div>
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/themes/_tk-master/img/bizPimages/img02.jpg');margin: 2px;"></div>
					</div>
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/themes/_tk-master/img/bizPimages/img04.jpg');margin: 2px 0 2px 2px;"></div>
					</div>
					<div class="thumb">
						<div class="image" style="background-image: url('/wp-content/themes/_tk-master/img/bizPimages/img03.jpg');margin: 2px;"></div>
					</div>
				</div>
			</div>

			 <div class="faces bgaqua">
			 	<h3>Kiara and 23456 other users like this</h3>
                <ul class="clearfix">
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/01.jpg" class="face">
                        <span>Claire</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/02.jpg" class="face">
                        <span>Tisha</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/03.jpg" class="face">
                        <span>Rob</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/04.jpg" class="face">
                        <span>Alina</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/05.jpg" class="face">
                        <span>Isabelle</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/06.jpg" class="face">
                        <span>Alan</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/07.jpg" class="face">
                        <span>Bea</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/08.jpg" class="face">
                        <span>John</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/09.jpg" class="face">
                        <span>Marry</span>
                    </li>
                </ul>
            </div>  

 

            <div class="about"><span class="ico ico-about"></span>About <span class="upper">Bali</span></div>

		</div>
	</div>
	<div class="biz_posts city">
		<p class="title aqua">Latest posts:</p>

		<div class="body">

			<table class="item-header">
				  <tr>
				    <td class="avatar"><img src="/wp-content/themes/_tk-master/img/flags/indonesia.png"></td>
				    <td class="captions">
				      <p class="name semi">Spa Promotion</p>
				      <p class="location bold">W Hotel</p>
				    </td>
				    <td class="actions">
				      	<img src="/wp-content/themes/_tk-master/img/love/shared.png" class="icon share"><br>
				    	23987 <img src="/wp-content/themes/_tk-master/img/love/love.png" class="icon love">      	
				    </td>
				  </tr>
				</table>
			<img src="/wp-content/themes/_tk-master/img/temp/spa.png" alt="" class="promo_img">
			<p class="tagline">We offer a wide array of treatments that promote relaxation and renewal.<br>
			Treatments start at 120$ and are reserved for guests aged 18 and older.</p>
		</div>
	</div>
</article><!-- #post-## -->


</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
