<?php

/**
 * Template name: Home
 *
 * @package _tk
 */

get_header();

?>

<?php get_sidebar(); ?>


<div id="content" class="content">

<?php if (!is_user_logged_in()) : ?>
    <p>Please login.</p>
<?php else : ?>

    <div class="tabs-bar">
        <ul class="nav nav-tabs bglaqua" role="tablist">
            <li class="active"><a href="#tab-1" aria-controls="tab-1" role="tab" data-toggle="tab" data-tab-name="new_logs"><span class="ico ico-travelogue"></span> New Logs</a></li>
            <li><a href="#tab-2" aria-controls="tab-2" role="tab" data-toggle="tab" data-tab-name="friends">Friends</a></li>
            <li><a href="#tab-3" aria-controls="tab-3" role="tab" data-toggle="tab" data-tab-name="favorites">Favorites</a></li>
            <?php if(get_current_user_id() == 9): ?>
            <li><a href="#tab-4" aria-controls="tab-4" role="tab" data-toggle="tab" data-tab-name="new_logs">New Logs Ajax</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane active" id="tab-1">     
           <div class="faces bgaqua">
               <ul class="clearfix">
                    <li>                    
                        <a href="/profile/?user=6"><img src="<?php bloginfo('template_directory'); ?>/img/people/01.jpg" class="face">
                        <span>Claire</span></a>
                    </li>
                    <li>                  
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/02.jpg" class="face">
                        <span>Tisha</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/03.jpg" class="face">
                        <span>Rob</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/04.jpg" class="face">
                        <span>Alina</span>
                    </li>
                    <li>                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/05.jpg" class="face">
                        <span>Isabelle</span>
                    </li>
                    <li class="hide_on_mobile">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/06.jpg" class="face">
                        <span>Alan</span>
                    </li>
                    <li class="hide_on_mobile">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/07.jpg" class="face">
                        <span>Bea</span>
                    </li>
                    <li class="hide_on_tablet hide_on_mobile">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/08.jpg" class="face">
                        <span>John</span>
                    </li>
                    <li class="hide_on_tablet hide_on_mobile">                    
                        <img src="<?php bloginfo('template_directory'); ?>/img/people/09.jpg" class="face">
                        <span>Marry</span>
                    </li>
                </ul>
            </div>
            <div class="feed bdaqua">
                <div class="ajax-response"></div>
                <div class="response"></div>
            </div>
        </div>
        <div role="tabpanel" class="tab-pane" id="tab-2">
           <div class="two_col_posts clearfix">
               <div class="ajax-response"></div>
               <div class="response"></div>
           </div>
        </div>
        <div role="tabpanel" class="tab-pane" id="tab-3">
            <div class="two_col_posts clearfix">
                <div class="ajax-response"></div>
                <div class="response"></div>
            </div>
        </div>
        <div role="tabpanel" class="tab-pane" id="tab-4">
            <div class="feed bdaqua">
                <div class="ajax-response"></div>
                <div class="response"></div>
            </div>
        </div>
    </div>

<script>

jQuery( function( $ ) {

    var adjust = function() {
        var width = $(window).width();
        var cover = $('#featured_cover');
        if (width > 600) {
            var totalH = $('.section-2').height();
            var thumbsH = $('.three_pics').width();
            cover.css('height', totalH -  (thumbsH-12)/3 - 10);
        } else if (width <= 600 && width > 400) {
            cover.css('height', '300px');
        } else if (width <= 400) {
            cover.css('height', '200px');
        }       
    }


    adjust();
    $(window).resize(function(){
        adjust();
    });

} );

</script>

<?php endif; ?>

</div>

<?php get_footer(); ?>

