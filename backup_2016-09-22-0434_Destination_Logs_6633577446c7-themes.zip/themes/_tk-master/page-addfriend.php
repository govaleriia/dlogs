<?php
/**
 * Template name: Add friend
 *
 * @package _tk
 */

get_header(); ?>

<?php get_sidebar(); ?>
    
<div id="content" class="content">

	<?php while ( have_posts() ) : the_post(); ?>

		<?php // get_template_part( 'content', 'add' ); ?>
		<img src="<?php bloginfo('template_directory'); ?>/img/temp/addfriend.png">

		<?php
			// If comments are open or we have at least one comment, load up the comment template
			if ( comments_open() || '0' != get_comments_number() )
				comments_template();
		?>

	<?php endwhile; // end of the loop. ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
