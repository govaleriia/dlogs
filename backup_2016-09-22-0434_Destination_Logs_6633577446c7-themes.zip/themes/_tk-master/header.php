<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package _tk
 */
?><!DOCTYPE html>

<?php 
if ( !is_user_logged_in() ) {
   auth_redirect();
}

?>

<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, user-scalable=no" >
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title><?php wp_title( '|', true, 'right' ); ?></title>

	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,500,700,900,300' rel='stylesheet' type='text/css'>
	<?php wp_head(); ?>
	<script src="http://dl4.nexdna.com/wp-content/themes/_tk-master/js/javascript.js"></script>
</head>



<body <?php body_class(); ?>>
	<?php do_action( 'before' ); ?>

<?php if (is_user_logged_in()) : ?>

<?php if (!is_page_template('page-register.php')) : ?>

<header id="masthead" class="site-header bgred">
    <div class="container nav-bar-container">
        <div class="row">
        	<div id="logo">
        		<a href="/home/" class="brand image-container"><img src="<?php bloginfo('template_directory'); ?>/img/logo1.png"></a>
        	</div>
     
        	<div id="navig">
	        	<div class="search-group">

	                <input type="text" class="form-control" placeholder="Search for Destinations, Friends and much more...">
	                <span class="ico ico-loupe_g ico-right"></span>
	            </div>
	            <nav class="nav-bar">
	                <ul>
	                    <li><a href="/my-profile/"><span class="icon icon-profile"></span></a></li>
	                    <li><a href="/add-new/"><span class="icon icon-add"></span></a></li>
	                    <li><a href="/home/"><span class="icon icon-feed"></span></a></li>
	                    <li><a href="/explore/"><span class="icon icon-explore"></span></a></li>
	                    <li><a href="/share/"><span class="icon icon-share"></span></a></li>
	                </ul>
	            </nav>
	        </div>
	
        </div>
    </div>
</header>	

<?php endif; ?>
<?php endif; ?>

<div class="main-content">
	<div class="container">
		<div class="row">
	


